use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};
use url::Url;

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[allow(non_snake_case)]
pub struct MediaStream {
    pub Type: Option<String>, pub Codec: Option<String>, pub Width: Option<i32>, pub Height: Option<i32>,
    pub BitRate: Option<i64>, pub Language: Option<String>, pub DisplayTitle: Option<String>, pub Title: Option<String>,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[allow(non_snake_case)]
pub struct MediaSource {
    pub Id: Option<String>, pub Name: Option<String>, pub Path: Option<String>, pub Container: Option<String>,
    pub Size: Option<i64>, pub Bitrate: Option<i64>, pub BitRate: Option<i64>, pub MediaStreams: Option<Vec<MediaStream>>,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[allow(non_snake_case)]
pub struct UserData { pub Played: Option<bool>, pub PlaybackPositionTicks: Option<i64> }

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[allow(non_snake_case)]
pub struct Item {
    pub Id: String,
    pub Name: String,
    pub Type: Option<String>,
    pub CollectionType: Option<String>,
    pub ParentId: Option<String>,
    pub IndexNumber: Option<i32>,
    pub ParentIndexNumber: Option<i32>,
    pub SeriesId: Option<String>,
    pub SeasonId: Option<String>,
    pub ProductionYear: Option<i32>,
    pub SeriesName: Option<String>, pub SeasonName: Option<String>, pub CommunityRating: Option<f64>,
    pub RunTimeTicks: Option<i64>, pub UserData: Option<UserData>,
    pub Width: Option<i32>, pub Height: Option<i32>, pub Bitrate: Option<i64>, pub BitRate: Option<i64>,
    pub Container: Option<String>, pub Size: Option<i64>, pub MediaStreams: Option<Vec<MediaStream>>,
    pub MediaSources: Option<Vec<MediaSource>>,
}

#[derive(Clone, Debug)]
pub struct Quality {
    pub source_id: Option<String>, pub name: String, pub width: i32, pub height: i32,
    pub bitrate: i64, pub size: i64, pub codec: String,
}

impl Quality {
    fn score(&self) -> (i64, i64) { (self.width as i64 * self.height as i64, self.bitrate) }
    fn resolution(&self) -> String {
        if self.width <= 0 || self.height <= 0 { return "Unknown resolution".into(); }
        let class = if self.height >= 2160 { "4K".into() } else if self.height >= 1440 { "1440p".into() }
            else if self.height >= 1080 { "1080p".into() } else if self.height >= 720 { "720p".into() }
            else if self.height >= 480 { "480p".into() } else { format!("{}p", self.height) };
        format!("{class} ({}×{})", self.width, self.height)
    }
    fn description(&self) -> String {
        let mut parts = vec![self.resolution()];
        if !self.codec.is_empty() { parts.push(self.codec.to_uppercase()); }
        if self.bitrate > 0 { parts.push(format!("{:.1} Mbps", self.bitrate as f64 / 1_000_000.0)); }
        if self.size > 0 { parts.push(format!("{:.2} GB", self.size as f64 / 1_000_000_000.0)); }
        if !self.name.is_empty() { parts.push(self.name.clone()); }
        parts.join(" · ")
    }
}

impl Item {
    pub fn qualities(&self) -> Vec<Quality> {
        let mut result: Vec<Quality> = self.MediaSources.as_deref().unwrap_or_default().iter().map(|source| {
            let video = source.MediaStreams.as_deref().unwrap_or_default().iter().find(|s| s.Type.as_deref().is_some_and(|v| v.eq_ignore_ascii_case("Video")));
            Quality { source_id: source.Id.clone(), name: source.Name.clone().or_else(|| source.Path.as_ref().and_then(|p| std::path::Path::new(p).file_name().map(|n| n.to_string_lossy().into_owned()))).unwrap_or_default(),
                width: video.and_then(|v| v.Width).or(self.Width).unwrap_or(0), height: video.and_then(|v| v.Height).or(self.Height).unwrap_or(0),
                bitrate: video.and_then(|v| v.BitRate).or(source.Bitrate).or(source.BitRate).or(self.Bitrate).or(self.BitRate).unwrap_or(0),
                size: source.Size.or(self.Size).unwrap_or(0), codec: video.and_then(|v| v.Codec.clone()).unwrap_or_default() }
        }).collect();
        if result.is_empty() {
            let video = self.MediaStreams.as_deref().unwrap_or_default().iter().find(|s| s.Type.as_deref().is_some_and(|v| v.eq_ignore_ascii_case("Video")));
            if video.is_some() || self.Width.is_some() || self.Height.is_some() || self.Bitrate.is_some() || self.BitRate.is_some() {
                result.push(Quality { source_id: None, name: String::new(), width: video.and_then(|v| v.Width).or(self.Width).unwrap_or(0),
                    height: video.and_then(|v| v.Height).or(self.Height).unwrap_or(0), bitrate: video.and_then(|v| v.BitRate).or(self.Bitrate).or(self.BitRate).unwrap_or(0),
                    size: self.Size.unwrap_or(0), codec: video.and_then(|v| v.Codec.clone()).unwrap_or_default() });
            }
        }
        result.sort_by_key(|q| std::cmp::Reverse(q.score())); result
    }
    pub fn quality_summary(&self) -> String {
        let q = self.qualities(); let Some(best) = q.first() else { return String::new(); };
        let mut parts = vec![best.resolution()];
        if !best.codec.is_empty() { parts.push(best.codec.to_uppercase()); }
        if best.bitrate > 0 { parts.push(format!("{:.1} Mbps", best.bitrate as f64 / 1_000_000.0)); }
        if q.len() > 1 { parts.push(format!("Best of {}", q.len())); } parts.join(" · ")
    }
    pub fn quality_details(&self) -> String {
        let q = self.qualities(); if q.is_empty() { return "No media quality details supplied by Jellyfin.".into(); }
        q.iter().enumerate().map(|(i, q)| format!("{} {}", if i == 0 { "★" } else { "•" }, q.description())).collect::<Vec<_>>().join("\n")
    }
}

#[derive(Clone, Debug, Deserialize)]
#[allow(non_snake_case)]
struct Items { Items: Option<Vec<Item>> }

#[derive(Deserialize)]
#[allow(non_snake_case)]
struct Authentication { AccessToken: String, User: User }
#[derive(Deserialize)]
#[allow(non_snake_case)]
struct User { Id: String }

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct QueueEntry { pub item_id: String, pub title: String, pub url: Url }
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PlaybackQueue { pub entries: Vec<QueueEntry>, pub index: usize }

#[derive(Clone)]
pub struct Jellyfin {
    pub server: Url,
    pub token: String,
    pub user_id: String,
    client: Client,
}

impl Jellyfin {
    pub fn login(server: &str, username: &str, password: &str) -> Result<Self, String> {
        let server = normalize(server)?;
        let client = Client::builder().build().map_err(|e| e.to_string())?;
        let url = server.join("Users/AuthenticateByName").map_err(|e| e.to_string())?;
        let response = client.post(url)
            .header("Authorization", auth_header(""))
            .json(&serde_json::json!({"Username": username, "Pw": password}))
            .send().map_err(|e| e.to_string())?;
        if !response.status().is_success() { return Err(format!("Jellyfin returned HTTP {}", response.status())); }
        let auth: Authentication = response.json().map_err(|e| e.to_string())?;
        Ok(Self { server, token: auth.AccessToken, user_id: auth.User.Id, client })
    }
    pub fn from_token(server: &str, token: String, user_id: String) -> Result<Self, String> {
        Ok(Self { server: normalize(server)?, token, user_id, client: Client::new() })
    }
    pub fn libraries(&self) -> Result<Vec<Item>, String> { self.get(&format!("Users/{}/Views", self.user_id), &[]) }
    pub fn children(&self, parent: &str, search: &str, sort: &str, descending: bool, filter: &str) -> Result<Vec<Item>, String> {
        let mut query = vec![
            ("ParentId", parent.to_string()), ("Recursive", (!search.is_empty()).to_string()),
            ("IncludeItemTypes", "Movie,Series,Season,Episode,Video,MusicVideo,Folder,BoxSet".into()),
            ("Fields", "ParentId,IndexNumber,ParentIndexNumber,SeriesId,SeasonId,SeriesName,SeasonName,ProductionYear,CommunityRating,RunTimeTicks,UserData,MediaSources,MediaStreams,Path,Size,Bitrate,Width,Height,Container".into()),
            ("EnableMedia", "true".into()),
            ("SortBy", sort.into()), ("SortOrder", if descending { "Descending" } else { "Ascending" }.into()),
            ("Limit", "1000".into()),
        ];
        if !search.is_empty() { query.push(("SearchTerm", search.into())); }
        if filter == "Unplayed" { query.push(("Filters", "IsUnplayed".into())); }
        else if filter == "Played" { query.push(("Filters", "IsPlayed".into())); }
        self.get(&format!("Users/{}/Items", self.user_id), &query)
    }
    pub fn series_queue(&self, selected: &Item) -> Result<PlaybackQueue, String> {
        let parent = selected.SeriesId.as_deref().or(selected.ParentId.as_deref()).ok_or("Episode has no series ID")?;
        let query = vec![
            ("ParentId", parent.to_string()), ("Recursive", "true".into()),
            ("IncludeItemTypes", "Episode".into()),
            ("Fields", "ParentId,IndexNumber,ParentIndexNumber,SeriesId,SeasonId,SeriesName,SeasonName,ProductionYear,CommunityRating,RunTimeTicks,UserData,MediaSources,MediaStreams,Path,Size,Bitrate,Width,Height,Container".into()),
            ("EnableMedia", "true".into()),
            ("Limit", "1000".into()),
        ];
        let mut episodes: Vec<Item> = self.get(&format!("Users/{}/Items", self.user_id), &query)?;
        episodes.sort_by_key(|e| (e.ParentIndexNumber.unwrap_or(0), e.IndexNumber.unwrap_or(0), e.Name.clone()));
        let entries: Vec<_> = episodes.iter().map(|e| QueueEntry { item_id: e.Id.clone(), title: e.Name.clone(), url: self.stream_url(e) }).collect();
        let index = entries.iter().position(|e| e.item_id == selected.Id).unwrap_or(0);
        Ok(PlaybackQueue { entries, index })
    }
    pub fn stream_url(&self, item: &Item) -> Url {
        let mut url = self.server.join(&format!("Videos/{}/stream", item.Id)).unwrap();
        url.query_pairs_mut().append_pair("Static", "true").append_pair("api_key", &self.token);
        if let Some(source_id) = item.qualities().first().and_then(|q| q.source_id.clone()) {
            url.query_pairs_mut().append_pair("MediaSourceId", &source_id);
        }
        url
    }
    fn get(&self, path: &str, query: &[(&str, String)]) -> Result<Vec<Item>, String> {
        let url = self.server.join(path).map_err(|e| e.to_string())?;
        let query: Vec<_> = query.iter().map(|(k, v)| (*k, v.as_str())).collect();
        let response = self.client.get(url).query(&query).header("Authorization", auth_header(&self.token)).header("X-Emby-Token", &self.token).send().map_err(|e| e.to_string())?;
        if !response.status().is_success() { return Err(format!("Jellyfin returned HTTP {}", response.status())); }
        Ok(response.json::<Items>().map_err(|e| e.to_string())?.Items.unwrap_or_default())
    }
}

fn normalize(value: &str) -> Result<Url, String> {
    let mut text = value.trim().to_string();
    if !text.contains("://") { text = format!("http://{text}"); }
    if !text.ends_with('/') { text.push('/'); }
    Url::parse(&text).map_err(|e| e.to_string())
}
fn auth_header(token: &str) -> String {
    format!("MediaBrowser Client=\"NTSC%20Player\", Device=\"Windows\", DeviceId=\"ntsc-player-windows\", Version=\"0.1.1\", Token=\"{token}\"")
}
