use librashader_common::{Size, Viewport};
use librashader_preprocess::ShaderSource;
use librashader_presets::{ShaderFeatures, ShaderPreset};
use librashader_runtime::parameters::FilterChainParameters;
use librashader_runtime_wgpu::{
    options::{FilterChainOptionsWgpu, FrameOptionsWgpu}, FilterChainWgpu, WgpuOutputView,
};
use std::collections::{BTreeMap, HashMap};
use std::path::{Path, PathBuf};

pub const STOCK_PRESETS: &[(&str, &str)] = &[
    ("CRT Geom", "crt/crt-geom.slangp"),
    ("CRT Royale Fast", "crt/crt-royale-fast.slangp"),
    ("CRT Hyllian", "crt/crt-hyllian.slangp"),
    ("CRT Lottes", "crt/crt-lottes.slangp"),
    ("CRT Easymode", "crt/crt-easymode.slangp"),
    ("New Pixie CRT", "crt/newpixie-crt.slangp"),
    ("NTSC Adaptive", "ntsc/ntsc-adaptive.slangp"),
    ("NTSC 320px Composite", "ntsc/ntsc-320px-composite.slangp"),
    ("VHS", "vhs/vhs.slangp"),
    ("NTSC VCR", "vhs/ntsc-vcr.slangp"),
    ("Gristle VHS", "vhs/gristleVHS.slangp"),
    ("Simple Scanlines", "scanlines/scanline.slangp"),
];

#[derive(Clone)]
pub struct ShaderParameter {
    pub name: String,
    pub description: String,
    pub initial: f32,
    pub minimum: f32,
    pub maximum: f32,
    pub step: f32,
}

struct GpuImages {
    width: u32,
    height: u32,
    padded_bytes_per_row: u32,
    input: wgpu::Texture,
    output: wgpu::Texture,
    readback: wgpu::Buffer,
}

pub struct ShaderEngine {
    _instance: wgpu::Instance,
    _adapter: wgpu::Adapter,
    device: wgpu::Device,
    queue: wgpu::Queue,
    chain: Option<FilterChainWgpu>,
    images: Option<GpuImages>,
    parameters: Vec<ShaderParameter>,
    loaded_preset: Option<PathBuf>,
    last_error: String,
    last_frame: Option<usize>,
}

impl ShaderEngine {
    pub fn new() -> Result<Self, String> {
        pollster::block_on(async {
            let instance = wgpu::Instance::default();
            let adapter = instance
                .request_adapter(&wgpu::RequestAdapterOptions {
                    power_preference: wgpu::PowerPreference::HighPerformance,
                    compatible_surface: None,
                    force_fallback_adapter: false,
                    apply_limit_buckets: false,
                })
                .await
                .map_err(|e| format!("No compatible shader GPU was found: {e}"))?;
            let wanted = wgpu::Features::ADDRESS_MODE_CLAMP_TO_BORDER
                | wgpu::Features::PIPELINE_CACHE
                | wgpu::Features::TEXTURE_ADAPTER_SPECIFIC_FORMAT_FEATURES
                | wgpu::Features::FLOAT32_FILTERABLE;
            let available = adapter.features();
            let required_features = wanted & available;
            let mut required_limits = wgpu::Limits::default();
            required_limits.max_inter_stage_shader_variables =
                adapter.limits().max_inter_stage_shader_variables;
            let (device, queue) = adapter
                .request_device(&wgpu::DeviceDescriptor {
                    label: Some("NTSC Player librashader device"),
                    required_features,
                    required_limits,
                    memory_hints: wgpu::MemoryHints::Performance,
                    experimental_features: Default::default(),
                    trace: Default::default(),
                })
                .await
                .map_err(|e| format!("Could not initialize the shader GPU: {e}"))?;
            Ok(Self {
                _instance: instance,
                _adapter: adapter,
                device,
                queue,
                chain: None,
                images: None,
                parameters: Vec::new(),
                loaded_preset: None,
                last_error: String::new(),
                last_frame: None,
            })
        })
    }

    pub fn load(&mut self, path: &Path) -> Result<(), String> {
        let features = ShaderFeatures::ORIGINAL_ASPECT_UNIFORMS
            | ShaderFeatures::FRAMETIME_UNIFORMS;
        let preset = ShaderPreset::try_parse(path, features)
            .map_err(|e| format!("Could not parse {}: {e}", path.display()))?;
        let parameters = parameter_metadata(&preset, features);
        let chain = FilterChainWgpu::load_from_preset(
            preset,
            &self.device,
            &self.queue,
            Some(&FilterChainOptionsWgpu {
                force_no_mipmaps: false,
                enable_cache: available_cache_features(&self._adapter),
                adapter_info: Some(self._adapter.get_info()),
            }),
        )
        .map_err(|e| format!("Could not compile {}: {e}", path.display()))?;
        self.chain = Some(chain);
        self.parameters = parameters;
        self.loaded_preset = Some(path.to_path_buf());
        self.last_frame = None;
        self.last_error.clear();
        Ok(())
    }

    pub fn loaded_preset(&self) -> Option<&Path> { self.loaded_preset.as_deref() }
    pub fn parameters(&self) -> &[ShaderParameter] { &self.parameters }
    pub fn last_error(&self) -> &str { &self.last_error }

    pub fn value(&self, index: usize) -> f32 {
        let Some(parameter) = self.parameters.get(index) else { return 0.0 };
        self.chain
            .as_ref()
            .and_then(|chain| chain.parameters().parameter_value(&parameter.name))
            .unwrap_or(parameter.initial)
    }

    pub fn set_value(&mut self, index: usize, value: f32) {
        if let (Some(chain), Some(parameter)) = (&self.chain, self.parameters.get(index)) {
            chain.parameters().set_parameter_value(&parameter.name, value);
        }
    }

    pub fn reset(&mut self) {
        if let Some(chain) = &self.chain {
            for parameter in &self.parameters {
                chain.parameters().set_parameter_value(&parameter.name, parameter.initial);
            }
        }
    }

    pub fn user_preset_text(&self) -> Option<String> {
        let source = self.loaded_preset.as_ref()?;
        let reference = source.to_string_lossy().replace('\\', "\\\\").replace('"', "\\\"");
        let mut text = format!("#reference \"{reference}\"\n");
        for (index, parameter) in self.parameters.iter().enumerate() {
            text.push_str(&format!("{} = \"{}\"\n", parameter.name, self.value(index)));
        }
        Some(text)
    }

    pub fn process_rgba(
        &mut self,
        pixels: &mut Vec<u8>,
        width: usize,
        height: usize,
        frame: usize,
        fps: f64,
    ) -> bool {
        if self.chain.is_none() || width == 0 || height == 0 { return false; }
        if let Err(error) = self.process_inner(pixels, width as u32, height as u32, frame, fps) {
            self.last_error = error;
            return false;
        }
        self.last_error.clear();
        true
    }

    fn process_inner(
        &mut self,
        pixels: &mut Vec<u8>,
        width: u32,
        height: u32,
        frame: usize,
        fps: f64,
    ) -> Result<(), String> {
        self.ensure_images(width, height);
        let images = self.images.as_ref().expect("images initialized");
        self.queue.write_texture(
            wgpu::TexelCopyTextureInfo {
                texture: &images.input,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            pixels,
            wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(width * 4),
                rows_per_image: Some(height),
            },
            wgpu::Extent3d { width, height, depth_or_array_layers: 1 },
        );

        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("NTSC Player shader frame"),
        });
        let output_view = images.output.create_view(&wgpu::TextureViewDescriptor::default());
        let output = WgpuOutputView::new_from_raw(
            &output_view,
            Size::new(width, height),
            wgpu::TextureFormat::Rgba8UnormSrgb,
        );
        let viewport = Viewport::new_render_target_sized_origin(output, None)
            .map_err(|_| "Could not create the shader viewport".to_string())?;
        let frame_direction = if self.last_frame.is_some_and(|last| frame < last) { -1 } else { 1 };
        let fps = if fps > 0.0 { fps as f32 } else { 30000.0 / 1001.0 };
        let options = FrameOptionsWgpu {
            frame_direction,
            aspect_ratio: width as f32 / height as f32,
            frames_per_second: fps,
            frametime_delta: (1_000_000.0 / fps).round() as u32,
            ..Default::default()
        };
        self.chain
            .as_mut()
            .expect("chain checked")
            .frame(&images.input, &viewport, &mut encoder, frame, Some(&options))
            .map_err(|e| format!("Shader frame failed: {e}"))?;
        encoder.copy_texture_to_buffer(
            images.output.as_image_copy(),
            wgpu::TexelCopyBufferInfo {
                buffer: &images.readback,
                layout: wgpu::TexelCopyBufferLayout {
                    offset: 0,
                    bytes_per_row: Some(images.padded_bytes_per_row),
                    rows_per_image: Some(height),
                },
            },
            wgpu::Extent3d { width, height, depth_or_array_layers: 1 },
        );
        let submission = self.queue.submit([encoder.finish()]);
        self.device
            .poll(wgpu::PollType::Wait { submission_index: Some(submission), timeout: None })
            .map_err(|e| format!("Shader GPU wait failed: {e}"))?;

        let (sender, receiver) = std::sync::mpsc::channel();
        images.readback.slice(..).map_async(wgpu::MapMode::Read, move |result| {
            let _ = sender.send(result);
        });
        self.device
            .poll(wgpu::PollType::Wait { submission_index: None, timeout: None })
            .map_err(|e| format!("Shader readback wait failed: {e}"))?;
        receiver.recv().map_err(|_| "Shader readback was interrupted".to_string())?
            .map_err(|e| format!("Shader readback failed: {e}"))?;
        {
            let mapped = images
                .readback
                .slice(..)
                .get_mapped_range()
                .map_err(|e| format!("Shader readback view failed: {e}"))?;
            let row_bytes = width as usize * 4;
            pixels.resize(row_bytes * height as usize, 0);
            for (row, source) in mapped.chunks(images.padded_bytes_per_row as usize).take(height as usize).enumerate() {
                pixels[row * row_bytes..(row + 1) * row_bytes].copy_from_slice(&source[..row_bytes]);
            }
        }
        images.readback.unmap();
        self.last_frame = Some(frame);
        Ok(())
    }

    fn ensure_images(&mut self, width: u32, height: u32) {
        if self.images.as_ref().is_some_and(|v| v.width == width && v.height == height) { return; }
        let format = wgpu::TextureFormat::Rgba8UnormSrgb;
        let size = wgpu::Extent3d { width, height, depth_or_array_layers: 1 };
        let input = self.device.create_texture(&wgpu::TextureDescriptor {
            label: Some("NTSC Player shader input"), size, mip_level_count: 1, sample_count: 1,
            dimension: wgpu::TextureDimension::D2, format,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
            view_formats: &[format],
        });
        let output = self.device.create_texture(&wgpu::TextureDescriptor {
            label: Some("NTSC Player shader output"), size, mip_level_count: 1, sample_count: 1,
            dimension: wgpu::TextureDimension::D2, format,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::COPY_SRC,
            view_formats: &[format],
        });
        let row_bytes = width * 4;
        let alignment = wgpu::COPY_BYTES_PER_ROW_ALIGNMENT;
        let padded_bytes_per_row = row_bytes.div_ceil(alignment) * alignment;
        let readback = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("NTSC Player shader readback"),
            size: padded_bytes_per_row as u64 * height as u64,
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        });
        self.images = Some(GpuImages { width, height, padded_bytes_per_row, input, output, readback });
    }
}

fn parameter_metadata(preset: &ShaderPreset, features: ShaderFeatures) -> Vec<ShaderParameter> {
    let overrides: HashMap<String, f32> = preset.parameters.iter()
        .map(|parameter| (parameter.name.to_string(), parameter.value)).collect();
    let mut result = BTreeMap::new();
    for pass in &preset.passes {
        let Ok(source) = ShaderSource::load(&pass.path, features) else { continue };
        for (name, parameter) in source.parameters {
            let name = name.to_string();
            result.entry(name.clone()).or_insert_with(|| ShaderParameter {
                name: name.clone(),
                description: parameter.description,
                initial: overrides.get(&name).copied().unwrap_or(parameter.initial),
                minimum: parameter.minimum,
                maximum: parameter.maximum,
                step: parameter.step,
            });
        }
    }
    result.into_values().collect()
}

fn available_cache_features(adapter: &wgpu::Adapter) -> bool {
    adapter.features().contains(wgpu::Features::PIPELINE_CACHE)
}

pub fn shader_root() -> Option<PathBuf> {
    let mut candidates = Vec::new();
    if let Ok(exe) = std::env::current_exe() && let Some(parent) = exe.parent() {
        candidates.push(parent.join("slang-shaders"));
    }
    candidates.push(PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("vendor/slang-shaders"));
    candidates.into_iter().find(|path| path.is_dir())
}

pub fn discover_presets(root: &Path) -> Vec<PathBuf> {
    fn visit(path: &Path, result: &mut Vec<PathBuf>) {
        let Ok(entries) = std::fs::read_dir(path) else { return };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() { visit(&path, result); }
            else if path.extension().is_some_and(|ext| ext.eq_ignore_ascii_case("slangp")) { result.push(path); }
        }
    }
    let mut result = Vec::new();
    visit(root, &mut result);
    result.sort_by_cached_key(|path| path.to_string_lossy().to_lowercase());
    result
}

pub fn display_path(root: &Path, path: &Path) -> String {
    path.strip_prefix(root).unwrap_or(path).to_string_lossy().replace('\\', "/")
}
