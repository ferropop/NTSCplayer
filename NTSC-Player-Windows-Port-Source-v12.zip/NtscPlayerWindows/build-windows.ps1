param(
    [string]$MpvDll = $env:LIBMPV_DLL,
    [switch]$DebugBuild
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) {
    throw "Rust is required. Install it from https://rustup.rs and select the stable MSVC toolchain."
}
if (-not $MpvDll) {
    $Candidates = @(
        "$Root\mpv-2.dll",
        "$Root\libmpv-2.dll",
        "$env:ProgramFiles\mpv\mpv-2.dll",
        "$env:LOCALAPPDATA\Programs\mpv\mpv-2.dll"
    )
    $MpvDll = $Candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $MpvDll -or -not (Test-Path $MpvDll)) {
    throw "Pass the path to mpv-2.dll with -MpvDll or set LIBMPV_DLL. The DLL must be the x64 libmpv build, not mpv.exe."
}

$ShaderRoot = Join-Path $Root "vendor\slang-shaders"
if (-not (Test-Path (Join-Path $ShaderRoot "presets"))) {
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        throw "Git is required to download the official libretro/slang-shaders collection."
    }
    Write-Host "Downloading the official RetroArch Slang shader collection..."
    git clone --depth 1 https://github.com/libretro/slang-shaders.git $ShaderRoot
    if ($LASTEXITCODE -ne 0) { throw "Could not download libretro/slang-shaders." }
}

$Profile = if ($DebugBuild) { "debug" } else { "release" }
if ($DebugBuild) { cargo build } else { cargo build --release }

$Dist = Join-Path $Root "dist\NTSC Player Windows"
New-Item -ItemType Directory -Force $Dist | Out-Null
Copy-Item "$Root\target\$Profile\ntsc-player-windows.exe" "$Dist\NTSC Player.exe" -Force
Copy-Item $MpvDll "$Dist\mpv-2.dll" -Force
Copy-Item "$Root\README.md" "$Dist\README.txt" -Force
Copy-Item $ShaderRoot "$Dist\slang-shaders" -Recurse -Force

$Zip = Join-Path $Root "dist\NTSC-Player-Windows-x64.zip"
if (Test-Path $Zip) { Remove-Item $Zip -Force }
Compress-Archive -Path "$Dist\*" -DestinationPath $Zip -CompressionLevel Optimal
Write-Host "Built: $Zip"
