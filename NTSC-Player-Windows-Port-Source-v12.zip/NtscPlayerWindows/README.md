# NTSC Player for Windows

Native Windows 10/11 x64 port of the macOS NTSC Player. It decodes and plays audio
through libmpv, processes displayed frames through the same vendored `ntsc-rs` core,
and renders through wgpu/Direct3D 12.

## Included

- Local files, mounted SMB/Samba paths, HTTP streams, and drag-and-drop
- Play/pause, ±10 seconds, timeline, volume, and fullscreen
- Full ntsc-rs parameter list with live controls and JSON preset import/export
- Complete RetroArch Slang/librashader engine with searchable access to all bundled presets
- Live controls and import/export for shader preset parameters
- Four stock ntsc-rs community presets and twelve quick-access shader presets
- CRT Fill mode crops widescreen sources to 4:3 while leaving native 4:3 unchanged
- The identical aggressive standalone saved-settings default used by the macOS build
- Jellyfin login, libraries, hierarchical Show → Season → Episode browsing, search, and sorting
- Full-series episode queues across seasons, plus sequential playback of playable siblings in Other/Home Videos folders
- Last video, queue, Jellyfin navigation, volume, and playback position persistence
- Fullscreen controls that appear with mouse movement and hide after two seconds
- P toggles the interactive effect panel
- C toggles CRT Fill (center-crop to 4:3)
- Windows display/system sleep blocking only while video is actively playing

The saved session is restored paused at its previous position. Press Space to continue.

## Build on Windows

Requirements:

1. Windows 10 or 11 x64
2. Stable x64 MSVC Rust from <https://rustup.rs>
3. Visual Studio 2022 Build Tools with **Desktop development with C++**
4. A 64-bit `mpv-2.dll`/libmpv build

PowerShell:

```powershell
.\build-windows.ps1 -MpvDll C:\path\to\mpv-2.dll
```

The portable archive is written to `dist\NTSC-Player-Windows-x64.zip`. Keep
`mpv-2.dll` beside `NTSC Player.exe`.

The exact ntsc-rs and librashader revisions used by the player are vendored. The
build script downloads the official `libretro/slang-shaders` collection when it
is not already present, then bundles the complete collection in the portable app.

## Build entirely on GitHub

The included **Build Windows x64** GitHub Actions workflow needs no secrets and no
Windows computer. Push the repository to GitHub, open **Actions**, select the workflow,
and choose **Run workflow**. When it finishes, download the
`NTSC-Player-Windows-x64` artifact from the run. The workflow compiles on a real
Windows runner and bundles the current standard x64 libmpv runtime automatically.

## Keyboard

- Space: play/pause
- Left/Right: seek 10 seconds
- F11: fullscreen
- P: effect controls
- B: bypass all video effects without changing their settings
- C: CRT Fill on/off

## Shader engine

Choose **Shaders engine** in the Effects panel. The built package includes the complete
official `libretro/slang-shaders` tree (more than 2,500 `.slangp` presets), a searchable
library, the same quick-access presets as the macOS build, external `.slangp` loading,
and editable runtime parameters. Keep the `slang-shaders` folder beside the executable.
