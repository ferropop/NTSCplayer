#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]

mod jellyfin;
mod mpv;
mod ntsc;
mod shader;
mod sleep;

use eframe::egui;
use jellyfin::{Item, Jellyfin, PlaybackQueue, QueueEntry};
use mpv::{MediaTrack, Mpv, TrackKind, END_FILE_REASON_EOF, END_FILE_REASON_STOP};
use ntsc::{ControlKind, Engine, SettingInfo};
use rayon::prelude::*;
use shader::{ShaderEngine, ShaderParameter};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::hash::{Hash, Hasher};
use std::path::PathBuf;
use std::time::{Duration, Instant};

const STATE_KEY: &str = "ntsc-player-windows-state-v1";

#[derive(Clone, Deserialize)]
struct NtscStockPreset {
    name: String,
    json: String,
    credit: String,
}

#[derive(Clone, Copy, Default, PartialEq, Eq, Hash, Serialize, Deserialize)]
enum EffectMode {
    #[default]
    Ntsc,
    Shaders,
}

#[derive(Clone, Copy, Default, PartialEq, Eq, Hash, Serialize, Deserialize)]
enum NtscFieldCadence { Frame, #[default] Fields, Custom }

#[derive(Clone, Copy, Default, PartialEq, Eq, Hash, Serialize, Deserialize)]
enum NtscProcessingResolution { #[default] Source, Lines1080, Lines720, Lines480 }

#[derive(Clone, Copy, Default, PartialEq, Eq, Hash, Serialize, Deserialize)]
enum ShaderInputMode { #[default] Source, Sd480, Retro240 }

#[derive(Clone, Default, Serialize, Deserialize)]
struct BrowserFolderState { scroll_y: f32, selected_item: Option<String> }

#[derive(Default, Serialize, Deserialize)]
#[serde(default)]
struct SavedState {
    server: String,
    username: String,
    token: String,
    user_id: String,
    library_id: Option<String>,
    navigation: Vec<(String, String, String)>,
    last_url: Option<String>,
    last_title: String,
    last_position: f64,
    was_playing: bool,
    queue: Option<PlaybackQueue>,
    volume: f64,
    crt_fill: bool,
    screen_fill: bool,
    effect_mode: EffectMode,
    ntsc_field_cadence: Option<u8>,
    ntsc_field_rate: Option<f64>,
    ntsc_state: Option<String>,
    shader_preset: Option<String>,
    shader_values: Vec<f32>,
    master_brightness: Option<f32>,
    ntsc_resolution: NtscProcessingResolution,
    shader_input: ShaderInputMode,
    shader_integer_scale: bool,
    bypass: bool,
    search: String,
    descending: bool,
    sort: String,
    filter: String,
    folder_states: BTreeMap<String, BrowserFolderState>,
}

struct WindowsPlayer {
    mpv: Option<Mpv>,
    engine: Engine,
    setting_infos: Vec<SettingInfo>,
    effect_mode: EffectMode,
    ntsc_field_cadence: NtscFieldCadence,
    ntsc_field_rate: f64,
    ntsc_field_rate_text: String,
    ntsc_field_index: u64,
    shader: Option<ShaderEngine>,
    shader_root: Option<PathBuf>,
    shader_presets: Vec<PathBuf>,
    shader_filter: String,
    shader_preset: Option<PathBuf>,
    master_brightness: f32,
    ntsc_resolution: NtscProcessingResolution,
    shader_input: ShaderInputMode,
    shader_integer_scale: bool,
    ntsc_stock_presets: Vec<NtscStockPreset>,
    texture: Option<egui::TextureHandle>,
    video_open: bool,
    current_url: Option<String>,
    title: String,
    playing: bool,
    still_frame_dirty: bool,
    still_frame_attempts: u32,
    still_frame_refresh_until: Option<Instant>,
    last_still_frame_attempt: Instant,
    ended_cleanly: bool,
    ready_for_eof: bool,
    last_playhead: f64,
    recovery_attempts: u32,
    last_recovery: Option<Instant>,
    resume_at: Option<f64>,
    queue: Option<PlaybackQueue>,
    volume: f64,
    bypass: bool,
    crt_fill: bool,
    screen_fill: bool,
    show_effects: bool,
    fullscreen: bool,
    controls_visible: bool,
    last_mouse: Option<egui::Pos2>,
    last_mouse_activity: Instant,
    sleep_blocked: bool,
    error: String,
    server: String,
    username: String,
    password: String,
    jellyfin: Option<Jellyfin>,
    show_jellyfin: bool,
    libraries: Vec<Item>,
    library_id: Option<String>,
    navigation: Vec<Item>,
    items: Vec<Item>,
    selected_item: Option<String>,
    search: String,
    descending: bool,
    sort: String,
    filter: String,
    folder_states: BTreeMap<String, BrowserFolderState>,
    current_folder_key: Option<String>,
    current_scroll_y: f32,
    pending_scroll_restore: Option<f32>,
    focus_jellyfin_search: bool,
    last_save: Instant,
    media_tracks: Vec<MediaTrack>,
    preferred_tracks_applied: bool,
    last_track_refresh: Instant,
    display_aspect: f32,
    display_pixel_size: (usize, usize),
}

impl WindowsPlayer {
    fn new(cc: &eframe::CreationContext<'_>) -> Self {
        let saved: SavedState = cc.storage.and_then(|s| eframe::get_value(s, STATE_KEY)).unwrap_or_default();
        let mut app = Self {
            mpv: Mpv::new().map_err(|e| e.to_string()).ok(), engine: Engine::new(), setting_infos: Engine::settings(),
            effect_mode: saved.effect_mode, ntsc_field_cadence: saved.ntsc_field_cadence.map(|v| match v { 0 => NtscFieldCadence::Frame, 2 => NtscFieldCadence::Custom, _ => NtscFieldCadence::Fields }).unwrap_or_else(|| if saved.ntsc_state.is_some() { NtscFieldCadence::Frame } else { NtscFieldCadence::Fields }),
            ntsc_field_rate: saved.ntsc_field_rate.filter(|v| v.is_finite() && (15.0..=120.0).contains(v)).unwrap_or(60_000.0 / 1_001.0),
            ntsc_field_rate_text: String::new(), ntsc_field_index: 0, shader: None, shader_root: shader::shader_root(), shader_presets: Vec::new(),
            shader_filter: String::new(), shader_preset: saved.shader_preset.map(PathBuf::from),
            master_brightness: saved.master_brightness.unwrap_or(1.0).clamp(0.0, 1.1),
            ntsc_resolution: saved.ntsc_resolution, shader_input: saved.shader_input, shader_integer_scale: saved.shader_integer_scale,
            ntsc_stock_presets: serde_json::from_str(include_str!("../resources/ntsc-stock-presets.json")).unwrap_or_default(),
            texture: None, video_open: false, current_url: None, title: "Drop a video here".into(), playing: false,
            still_frame_dirty: false, still_frame_attempts: 0, still_frame_refresh_until: None,
            last_still_frame_attempt: Instant::now() - Duration::from_secs(1), ended_cleanly: false,
            ready_for_eof: false, last_playhead: 0.0, recovery_attempts: 0, last_recovery: None,
            resume_at: None, queue: None, volume: if saved.volume > 0.0 { saved.volume } else { 0.85 },
            bypass: saved.bypass, crt_fill: saved.crt_fill, screen_fill: saved.screen_fill, show_effects: false, fullscreen: false, controls_visible: true, last_mouse: None,
            last_mouse_activity: Instant::now(), sleep_blocked: false, error: String::new(),
            server: if saved.server.is_empty() { "http://localhost:8096".into() } else { saved.server.clone() },
            username: saved.username.clone(), password: String::new(), jellyfin: None, show_jellyfin: false,
            libraries: Vec::new(), library_id: saved.library_id.clone(), navigation: Vec::new(), items: Vec::new(),
            selected_item: None, search: saved.search.clone(), descending: saved.descending,
            sort: if saved.sort.is_empty() { "SortName".into() } else { saved.sort.clone() },
            filter: if saved.filter.is_empty() { "All".into() } else { saved.filter.clone() },
            folder_states: saved.folder_states.clone(), current_folder_key: None, current_scroll_y: 0.0,
            pending_scroll_restore: None, focus_jellyfin_search: false, last_save: Instant::now(),
            media_tracks: Vec::new(), preferred_tracks_applied: false, last_track_refresh: Instant::now(), display_aspect: 16.0 / 9.0,
            display_pixel_size: (1280, 720),
        };
        app.ntsc_field_rate_text = app.ntsc_field_rate.to_string();
        if let Some(state) = saved.ntsc_state.as_deref() { let _ = app.engine.load_json(state); }
        if let Some(root) = &app.shader_root { app.shader_presets = shader::discover_presets(root); }
        app.shader_presets.extend(discover_personal_presets("Shaders", "slangp"));
        app.shader_presets.sort_by_cached_key(|path| path.to_string_lossy().to_lowercase());
        if app.effect_mode == EffectMode::Shaders {
            let preset = app.shader_preset.clone().or_else(|| app.stock_shader_path(0));
            if let Some(path) = preset {
                app.load_shader(path);
                for (index, value) in saved.shader_values.iter().copied().enumerate() {
                    if let Some(shader) = &mut app.shader { shader.set_value(index, value); }
                }
            }
        }
        let output_rate = app.output_rate();
        if let Some(mpv) = &mut app.mpv { mpv.set_volume(app.volume); mpv.set_crt_fill(app.crt_fill); mpv.set_ntsc_cadence(app.effect_mode != EffectMode::Shaders, app.ntsc_field_cadence != NtscFieldCadence::Frame, output_rate); }
        if !saved.token.is_empty() {
            if let Ok(client) = Jellyfin::from_token(&saved.server, saved.token, saved.user_id) {
                app.jellyfin = Some(client);
                app.load_libraries();
                app.restore_navigation(saved.navigation);
            }
        }
        if let Some(url) = saved.last_url { app.open_source(url, saved.last_title, saved.queue, Some(saved.last_position), saved.was_playing); }
        if app.mpv.is_none() { app.error = "mpv-2.dll is missing. Put it beside NTSC Player.exe.".into(); }
        app
    }

    fn open_source(&mut self, source: String, title: String, queue: Option<PlaybackQueue>, resume: Option<f64>, autoplay: bool) {
        let output_rate = self.output_rate();
        let Some(mpv) = &mut self.mpv else { return };
        match mpv.load(&source) {
            Ok(()) => {
                self.current_url = Some(source); self.title = title; self.queue = queue; self.video_open = true;
                self.resume_at = resume.filter(|v| *v > 0.0); self.last_playhead = resume.unwrap_or(0.0).max(0.0);
                self.recovery_attempts = 0; self.last_recovery = None;
                self.ntsc_field_index = (resume.unwrap_or(0.0).max(0.0) * output_rate).floor() as u64;
                self.playing = autoplay; self.ended_cleanly = false; self.ready_for_eof = false;
                self.media_tracks.clear(); self.preferred_tracks_applied = false; self.last_track_refresh = Instant::now();
                mpv.set_paused(!autoplay); mpv.set_volume(self.volume);
                if !autoplay { self.mark_still_frame_dirty(Duration::from_millis(500)); }
                self.error.clear(); self.sync_sleep();
            }
            Err(e) => self.error = e,
        }
    }
    fn output_rate(&self) -> f64 { match self.ntsc_field_cadence { NtscFieldCadence::Frame => 30_000.0 / 1_001.0, NtscFieldCadence::Fields => 60_000.0 / 1_001.0, NtscFieldCadence::Custom => self.ntsc_field_rate } }
    fn field_index(&self, time: f64) -> u64 { (time.max(0.0) * self.output_rate()).floor() as u64 }
    fn mark_still_frame_dirty(&mut self, settle_for: Duration) {
        if self.playing || !self.video_open { return; }
        self.still_frame_dirty = true;
        self.still_frame_attempts = 0;
        self.last_still_frame_attempt = Instant::now() - Duration::from_secs(1);
        if !settle_for.is_zero() { self.still_frame_refresh_until = Some(Instant::now() + settle_for); }
    }

    fn visual_signature(&self) -> u64 {
        let mut hash = std::collections::hash_map::DefaultHasher::new();
        self.effect_mode.hash(&mut hash);
        self.ntsc_field_cadence.hash(&mut hash);
        self.ntsc_field_rate.to_bits().hash(&mut hash);
        self.ntsc_resolution.hash(&mut hash);
        self.shader_input.hash(&mut hash);
        self.shader_integer_scale.hash(&mut hash);
        self.crt_fill.hash(&mut hash);
        self.screen_fill.hash(&mut hash);
        self.bypass.hash(&mut hash);
        self.master_brightness.to_bits().hash(&mut hash);
        self.display_aspect.to_bits().hash(&mut hash);
        self.display_pixel_size.hash(&mut hash);
        self.engine.json().hash(&mut hash);
        self.shader_preset.hash(&mut hash);
        if let Some(shader) = &self.shader {
            for index in 0..shader.parameters().len() { shader.value(index).to_bits().hash(&mut hash); }
        }
        hash.finish()
    }

    fn seek_and_reset_field(&mut self, value: f64, relative: bool) {
        let time = if let Some(mpv) = &mut self.mpv { mpv.seek(value, relative); mpv.time() } else { return };
        self.ntsc_field_index = self.field_index(time);
        self.mark_still_frame_dirty(Duration::from_millis(350));
    }
    fn open_file(&mut self, path: PathBuf) { self.open_source(path.to_string_lossy().to_string(), path.file_name().unwrap_or_default().to_string_lossy().to_string(), None, None, true); }
    fn toggle_play(&mut self) {
        if !self.video_open { if let Some(path) = rfd::FileDialog::new().pick_file() { self.open_file(path); } return; }
        if !self.playing && self.ended_cleanly {
            if let Some(source) = self.current_url.clone() {
                self.open_source(source, self.title.clone(), self.queue.clone(), None, true);
            }
            return;
        }
        self.playing = !self.playing;
        if !self.playing {
            self.still_frame_dirty = false;
            self.still_frame_refresh_until = None;
        }
        if let Some(mpv) = &mut self.mpv {
            if self.playing && mpv.eof() { mpv.seek(0.0, false); self.ready_for_eof = false; }
            mpv.set_paused(!self.playing);
        }
        self.sync_sleep();
    }
    fn play_queue_index(&mut self, index: usize) {
        let Some(mut queue) = self.queue.clone() else { return };
        let Some(entry) = queue.entries.get(index).cloned() else { return };
        queue.index = index;
        self.open_source(entry.url.to_string(), entry.title, Some(queue), None, true);
    }
    fn previous_episode(&mut self) { if let Some(q) = &self.queue && q.index > 0 { self.play_queue_index(q.index - 1); } }
    fn next_episode(&mut self) { if let Some(q) = &self.queue && q.index + 1 < q.entries.len() { self.play_queue_index(q.index + 1); } }
    fn sync_sleep(&mut self) {
        let should = self.playing && self.video_open;
        if should != self.sleep_blocked { sleep::set_playing(should); self.sleep_blocked = should; }
    }
    fn recover_current_playback(&mut self, reason: i32) {
        let Some(source) = self.current_url.clone() else { return };
        let Some(mpv) = &mut self.mpv else { return };
        let now = Instant::now();
        if self.last_recovery.map(|last| now.duration_since(last) < Duration::from_secs(10)).unwrap_or(false) {
            self.recovery_attempts += 1;
        } else {
            self.recovery_attempts = 1;
        }
        self.last_recovery = Some(now);
        if self.recovery_attempts > 3 {
            self.playing = false;
            mpv.set_paused(true);
            self.error = "Playback stopped before the end. I did not advance to the next episode; press Play to retry this episode.".into();
            self.sync_sleep();
            return;
        }
        let resume = (self.last_playhead - 2.0).max(0.0);
        match mpv.load(&source) {
            Ok(()) => {
                self.resume_at = Some(resume);
                self.ended_cleanly = false;
                self.ready_for_eof = false;
                self.playing = true;
                mpv.set_paused(false);
                self.error = format!("Playback hiccup recovered at {}. Staying on this episode.", format_time(resume));
                self.sync_sleep();
            }
            Err(_) => {
                self.playing = false;
                self.error = format!("Playback stopped before the end (mpv reason {reason}). I did not advance to the next episode.");
                self.sync_sleep();
            }
        }
    }
    fn update_video(&mut self, ctx: &egui::Context) {
        if !self.video_open { return; }
        if !self.playing {
            if !self.still_frame_dirty { return; }
            if self.last_still_frame_attempt.elapsed() < Duration::from_millis(80) { return; }
            self.last_still_frame_attempt = Instant::now();
            self.still_frame_attempts += 1;
            if self.still_frame_attempts > 50 {
                self.still_frame_dirty = false;
                self.still_frame_refresh_until = None;
                return;
            }
        }
        if self.last_track_refresh.elapsed() >= Duration::from_millis(300) {
            self.last_track_refresh = Instant::now();
            if let Some(mpv) = &self.mpv {
                let mut tracks = mpv.tracks();
                if !tracks.is_empty() {
                    if !self.preferred_tracks_applied {
                        if let Some(track) = tracks.iter().find(|t| t.kind == TrackKind::Audio && is_english_track(t)) {
                            if !tracks.iter().any(|t| t.kind == TrackKind::Audio && t.selected) ||
                               !tracks.iter().any(|t| t.kind == TrackKind::Audio && t.selected && is_english_track(t)) {
                                if let Some(mpv) = &mut self.mpv { mpv.select_audio(track.id); }
                            }
                        }
                        if let Some(track) = tracks.iter().find(|t| t.kind == TrackKind::Subtitle && is_english_track(t)) {
                            if let Some(mpv) = &mut self.mpv { mpv.select_subtitle(Some(track.id)); }
                        }
                        self.preferred_tracks_applied = true;
                        tracks = self.mpv.as_ref().map(Mpv::tracks).unwrap_or(tracks);
                    }
                    self.media_tracks = tracks;
                }
            }
        }
        let end_reason = {
            let Some(mpv) = &mut self.mpv else { return };
            let time = mpv.time();
            let duration = mpv.duration();
            if duration > 0.0 {
                if let Some(position) = self.resume_at.take() { mpv.seek(position.min((duration - 0.05).max(0.0)), false); }
                if !mpv.eof() { self.ready_for_eof = true; }
            }
            if time.is_finite() && time > 0.0 && !mpv.eof() { self.last_playhead = time; }
            mpv.take_end_file_reason()
        };
        if let Some(reason) = end_reason {
            if reason == END_FILE_REASON_STOP {
                // mpv emits STOP for intentional load/replace paths. It is not episode completion.
            } else if reason == END_FILE_REASON_EOF && self.playing {
                // END_FILE/EOF is mpv's authoritative clean-completion signal. Do not compare the
                // final timestamp with container duration: valid files often finish several seconds
                // short of that declared duration, and mpv may clear time-pos as EOF is emitted.
                if let Some(q) = &self.queue && q.index + 1 < q.entries.len() { self.next_episode(); return; }
                self.playing = false;
                self.ended_cleanly = true;
                self.still_frame_dirty = false;
                self.still_frame_refresh_until = None;
                if let Some(mpv) = &mut self.mpv { mpv.set_paused(true); }
                self.sync_sleep();
            } else if self.playing {
                self.recover_current_playback(reason);
                return;
            }
        }
        let Some(mpv) = &mut self.mpv else { return };
        let Some((mut width, mut height)) = mpv.size() else { return };
        let limit = match self.effect_mode {
            EffectMode::Ntsc => match self.ntsc_resolution {
                NtscProcessingResolution::Source => None,
                NtscProcessingResolution::Lines1080 => Some((1920.0, 1080.0)),
                NtscProcessingResolution::Lines720 => Some((1280.0, 720.0)),
                NtscProcessingResolution::Lines480 => Some((854.0, 480.0)),
            },
            EffectMode::Shaders => match self.shader_input {
                ShaderInputMode::Source => None,
                ShaderInputMode::Sd480 => Some((854.0, 480.0)),
                ShaderInputMode::Retro240 => Some((426.0, 240.0)),
            },
        };
        let scale = limit.map(|(w, h)| (w / width as f32).min(h / height as f32).min(1.0)).unwrap_or(1.0);
        width = (width as f32 * scale).round() as usize; height = (height as f32 * scale).round() as usize;
        let time = mpv.time();
        let fps = mpv.fps();
        let field_cadence_active = self.effect_mode == EffectMode::Ntsc && self.ntsc_field_cadence != NtscFieldCadence::Frame;
        let field_index = if self.ntsc_field_cadence == NtscFieldCadence::Custom {
            (time.max(0.0) * self.ntsc_field_rate).floor() as u64
        } else { self.ntsc_field_index };
        let frame_number = if field_cadence_active { field_index as usize } else { (time * fps.max(1.0)).max(0.0) as usize };
        let Some(mut pixels) = mpv.render(width, height) else { return };
        let uncropped = (width, height);
        if self.screen_fill || (self.crt_fill && width * 3 > height * 4) {
            let target_aspect = if self.screen_fill { self.display_aspect } else { 4.0 / 3.0 };
            let (cropped, cropped_width, cropped_height) = crop_bgr0(&pixels, width, height, target_aspect);
            pixels = cropped; width = cropped_width; height = cropped_height;
        }
        // Crop only the clean image, then size it for the presentation area.
        // The uncropped source sets a fixed effect-pixel density for all crop modes.
        let presentation = effect_raster_size(
            width, height, self.display_pixel_size.0, self.display_pixel_size.1,
            uncropped.0, uncropped.1,
        );
        if presentation != (width, height) {
            pixels = resize_bgr0(&pixels, width, height, presentation.0, presentation.1);
            (width, height) = presentation;
        }
        match (self.bypass, self.effect_mode) {
            (false, EffectMode::Ntsc) => {
                if field_cadence_active { self.engine.process_field(&mut pixels, width, height, frame_number, field_index & 1 == 0); }
                else { self.engine.process(&mut pixels, width, height, frame_number); }
                bgr0_to_rgba(&mut pixels);
            }
            (false, EffectMode::Shaders) => {
                bgr0_to_rgba(&mut pixels);
                if let Some(shader) = &mut self.shader {
                    if !shader.process_rgba(&mut pixels, width, height, frame_number, fps) {
                        self.error = shader.last_error().to_string();
                    }
                }
            }
            _ => bgr0_to_rgba(&mut pixels),
        }
        if field_cadence_active && !self.bypass {
            self.ntsc_field_index = if self.ntsc_field_cadence == NtscFieldCadence::Custom { field_index }
                else { self.ntsc_field_index.saturating_add(1) };
        }
        apply_master_brightness(&mut pixels, if self.bypass { 1.0 } else { self.master_brightness });
        let image = egui::ColorImage::from_rgba_unmultiplied([width, height], &pixels);
        if let Some(texture) = &mut self.texture { texture.set(image, egui::TextureOptions::LINEAR); }
        else { self.texture = Some(ctx.load_texture("video", image, egui::TextureOptions::LINEAR)); }
        if !self.playing {
            self.still_frame_dirty = self.still_frame_refresh_until.is_some_and(|until| Instant::now() < until);
            if !self.still_frame_dirty { self.still_frame_refresh_until = None; }
        }
    }

    fn connect_jellyfin(&mut self) {
        match Jellyfin::login(&self.server, &self.username, &self.password) {
            Ok(client) => { self.jellyfin = Some(client); self.password.clear(); self.error.clear(); self.load_libraries(); }
            Err(e) => self.error = e,
        }
    }
    fn load_libraries(&mut self) {
        if let Some(client) = &self.jellyfin { match client.libraries() { Ok(v) => self.libraries = v, Err(e) => self.error = e } }
    }
    fn load_children(&mut self) {
        self.capture_browser_position();
        let forced_scroll = self.pending_scroll_restore.take();
        let Some(parent) = self.navigation.last().map(|i| i.Id.clone()).or(self.library_id.clone()) else { return };
        if let Some(client) = &self.jellyfin {
            match client.children(&parent, &self.search, &self.sort, self.descending, &self.filter) {
                Ok(v) => {
                    self.items = organize(v, self.navigation.last().and_then(|i| i.Type.as_deref()));
                    let key = self.browser_key();
                    let restored = self.folder_states.get(&key).cloned().unwrap_or_default();
                    self.selected_item = restored.selected_item;
                    let scroll = forced_scroll.unwrap_or(restored.scroll_y);
                    self.pending_scroll_restore = Some(scroll);
                    self.current_scroll_y = scroll;
                    self.current_folder_key = Some(key);
                }
                Err(e) => self.error = e,
            }
        }
    }
    fn browser_key(&self) -> String {
        let parent = self.navigation.last().map(|i| i.Id.as_str()).or(self.library_id.as_deref()).unwrap_or("none");
        let search = self.search.trim();
        if search.is_empty() { parent.into() } else { format!("{parent}\u{1f}{search}") }
    }
    fn capture_browser_position(&mut self) {
        let Some(key) = self.current_folder_key.clone() else { return };
        self.folder_states.insert(key, BrowserFolderState { scroll_y: self.current_scroll_y, selected_item: self.selected_item.clone() });
    }
    fn restore_navigation(&mut self, path: Vec<(String, String, String)>) {
        if let Some((id, _, _)) = path.first() { self.library_id = Some(id.clone()); }
        self.navigation = path.into_iter().skip(1).map(|(Id, Name, kind)| Item { Id, Name, Type: Some(kind), ..Default::default() }).collect();
        self.load_children();
    }
    fn play_jellyfin_item(&mut self, item: Item) {
        let queue_current_folder = should_queue_current_folder(
            self.libraries.iter()
                .find(|library| Some(&library.Id) == self.library_id.as_ref())
                .and_then(|library| library.CollectionType.as_deref()),
            &self.search,
        );
        let folder_items = queue_current_folder.then(|| self.items.clone());
        let Some(client) = &self.jellyfin else { return };
        if let Some(folder_items) = folder_items {
            let entries: Vec<_> = folder_items.iter()
                .filter(|candidate| is_playable_item(candidate))
                .map(|candidate| QueueEntry {
                    item_id: candidate.Id.clone(),
                    title: candidate.Name.clone(),
                    url: client.stream_url(candidate),
                })
                .collect();
            let index = entries.iter().position(|entry| entry.item_id == item.Id).unwrap_or(0);
            let queue = PlaybackQueue { entries, index };
            if let Some(entry) = queue.entries.get(queue.index).cloned() {
                self.open_source(entry.url.to_string(), entry.title, Some(queue), None, true);
                self.show_jellyfin = false;
            }
        } else if item.Type.as_deref() == Some("Episode") {
            match client.series_queue(&item) {
                Ok(queue) => { let entry = queue.entries[queue.index].clone(); self.open_source(entry.url.to_string(), entry.title, Some(queue), None, true); self.show_jellyfin = false; }
                Err(e) => self.error = e,
            }
        } else {
            self.open_source(client.stream_url(&item).to_string(), item.Name, None, None, true); self.show_jellyfin = false;
        }
    }

    fn stock_shader_path(&self, index: usize) -> Option<PathBuf> {
        let (_, relative) = shader::STOCK_PRESETS.get(index)?;
        let path = self.shader_root.as_ref()?.join(relative);
        path.is_file().then_some(path)
    }

    fn ensure_shader(&mut self) -> bool {
        if self.shader.is_some() { return true; }
        match ShaderEngine::new() {
            Ok(shader) => { self.shader = Some(shader); true }
            Err(error) => { self.error = error; false }
        }
    }

    fn load_shader(&mut self, path: PathBuf) {
        if !self.ensure_shader() { return; }
        match self.shader.as_mut().expect("shader initialized").load(&path) {
            Ok(()) => { self.shader_preset = Some(path); self.error.clear(); }
            Err(error) => self.error = error,
        }
    }

    fn effects_ui(&mut self, ui: &mut egui::Ui) {
        ui.heading("Master brightness");
        let brightness = ui.add(egui::Slider::new(&mut self.master_brightness, 0.0..=1.1).custom_formatter(|value, _| format!("{:.0}%", value * 100.0)));
        if brightness.double_clicked() { self.master_brightness = 1.0; }
        ui.small("0–110% · double-click to reset to 100%");
        ui.separator();
        ui.heading("Crop / fill");
        ui.label("Choose how the video uses the current display area.");
        ui.horizontal(|ui| {
            if ui.selectable_label(!self.crt_fill && !self.screen_fill, "Off").clicked() { self.crt_fill = false; self.screen_fill = false; if let Some(mpv) = &mut self.mpv { mpv.set_crt_fill(false); } }
            if ui.selectable_label(self.crt_fill, format!("4:3 Fill: {}", if self.crt_fill { "On" } else { "Off" })).on_hover_text("Crop to 4:3 (the C shortcut)").clicked() { self.crt_fill = !self.crt_fill; self.screen_fill = false; if let Some(mpv) = &mut self.mpv { mpv.set_crt_fill(self.crt_fill); } }
            if ui.selectable_label(self.screen_fill, format!("Crop to Fill: {}", if self.screen_fill { "On" } else { "Off" })).on_hover_text("Crop the minimum amount needed to fill the current window/display").clicked() { self.toggle_screen_fill(); }
        });
        ui.separator();
        ui.heading("Video effect");
        let previous_mode = self.effect_mode;
        ui.horizontal(|ui| {
            ui.selectable_value(&mut self.effect_mode, EffectMode::Ntsc, "NTSC engine");
            ui.selectable_value(&mut self.effect_mode, EffectMode::Shaders, "Shaders engine");
        });
        if previous_mode != self.effect_mode {
            self.ntsc_field_index = self.field_index(self.mpv.as_ref().map(Mpv::time).unwrap_or(0.0));
            let rate = self.output_rate();
            if let Some(mpv) = &mut self.mpv { mpv.set_ntsc_cadence(self.effect_mode == EffectMode::Ntsc, self.ntsc_field_cadence != NtscFieldCadence::Frame, rate); }
        }
        if previous_mode != self.effect_mode && self.effect_mode == EffectMode::Shaders && self.shader_preset.is_none() {
            if let Some(path) = self.stock_shader_path(0) { self.load_shader(path); }
        }
        ui.checkbox(&mut self.bypass, "Bypass all effects (B)")
            .on_hover_text("Temporarily show decoded video at normal brightness while preserving every effect setting.");
        ui.separator();

        match self.effect_mode {
            EffectMode::Ntsc => self.ntsc_effects_ui(ui),
            EffectMode::Shaders => self.shader_effects_ui(ui),
        }
    }

    fn ntsc_effects_ui(&mut self, ui: &mut egui::Ui) {
        let previous = self.ntsc_field_cadence;
        egui::ComboBox::from_label("NTSC temporal cadence")
            .selected_text(match self.ntsc_field_cadence { NtscFieldCadence::Frame => "Legacy frame-rate processing", NtscFieldCadence::Fields => "Field-rate · 59.94 Hz", NtscFieldCadence::Custom => "Custom field rate…" })
            .show_ui(ui, |ui| {
                ui.selectable_value(&mut self.ntsc_field_cadence, NtscFieldCadence::Frame, "Legacy frame-rate processing");
                ui.selectable_value(&mut self.ntsc_field_cadence, NtscFieldCadence::Fields, "Field-rate · 59.94 Hz");
                ui.selectable_value(&mut self.ntsc_field_cadence, NtscFieldCadence::Custom, "Custom field rate…");
            });
        ui.small("Field modes alternate upper/lower NTSC fields; the cadence does not modify the saved preset.");
        if previous != self.ntsc_field_cadence {
            self.ntsc_field_index = self.field_index(self.mpv.as_ref().map(Mpv::time).unwrap_or(0.0));
            let rate = self.output_rate();
            if let Some(mpv) = &mut self.mpv { mpv.set_ntsc_cadence(true, self.ntsc_field_cadence != NtscFieldCadence::Frame, rate); }
        }
        if self.ntsc_field_cadence == NtscFieldCadence::Custom {
            ui.horizontal(|ui| {
                ui.label("Custom field output rate (Hz)");
                let slider = ui.add(egui::Slider::new(&mut self.ntsc_field_rate, 15.0..=120.0).show_value(false));
                if slider.changed() {
                    self.ntsc_field_rate_text = self.ntsc_field_rate.to_string();
                }
                let input = ui.add(egui::TextEdit::singleline(&mut self.ntsc_field_rate_text).desired_width(110.0));
                let submit = input.lost_focus() || (input.has_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)));
                if submit {
                    if let Some(rate) = parse_field_rate(&self.ntsc_field_rate_text) {
                        self.ntsc_field_rate = rate;
                    } else {
                        self.ntsc_field_rate_text = self.ntsc_field_rate.to_string();
                    }
                }
                if slider.changed() || submit {
                    let rate = self.output_rate();
                    self.ntsc_field_index = self.field_index(self.mpv.as_ref().map(Mpv::time).unwrap_or(0.0));
                    if let Some(mpv) = &mut self.mpv { mpv.set_ntsc_cadence(true, true, rate); }
                }
            });
            ui.small("Enter a decimal or fraction such as 60000/1001 (15–120 Hz); press Enter or click away.");
        }
        egui::ComboBox::from_label("NTSC processing resolution")
            .selected_text(match self.ntsc_resolution { NtscProcessingResolution::Source => "Source resolution", NtscProcessingResolution::Lines1080 => "1080 lines", NtscProcessingResolution::Lines720 => "720 lines", NtscProcessingResolution::Lines480 => "480 lines · SD" })
            .show_ui(ui, |ui| {
                ui.selectable_value(&mut self.ntsc_resolution, NtscProcessingResolution::Source, "Source resolution");
                ui.selectable_value(&mut self.ntsc_resolution, NtscProcessingResolution::Lines1080, "1080 lines");
                ui.selectable_value(&mut self.ntsc_resolution, NtscProcessingResolution::Lines720, "720 lines");
                ui.selectable_value(&mut self.ntsc_resolution, NtscProcessingResolution::Lines480, "480 lines · SD");
            });
        ui.horizontal(|ui| {
            if ui.button("Reset").clicked() { self.engine.reset(); }
            if ui.button("Load preset…").clicked() && let Some(path) = rfd::FileDialog::new().set_directory(personal_preset_directory("NTSC")).add_filter("JSON", &["json"]).pick_file() {
                match std::fs::read_to_string(path) { Ok(text) if self.engine.load_json(&text) => {}, _ => self.error = "That is not a compatible ntsc-rs preset".into() }
            }
            if ui.button("Save preset…").clicked() && let Some(path) = rfd::FileDialog::new().set_directory(personal_preset_directory("NTSC")).add_filter("JSON", &["json"]).set_file_name("My Preset.json").save_file() {
                if let Some(json) = self.engine.json() { if let Err(e) = std::fs::write(path, json) { self.error = e.to_string(); } }
            }
        });
        if !self.ntsc_stock_presets.is_empty() {
            ui.label("Stock ntsc-rs presets");
            let presets = self.ntsc_stock_presets.clone();
            for preset in presets {
                if ui.button(&preset.name).on_hover_text(&preset.credit).clicked() {
                    if !self.engine.load_json(&preset.json) { self.error = format!("Could not load {}", preset.name); }
                }
            }
        }
        let personal = discover_personal_presets("NTSC", "json");
        if !personal.is_empty() {
            ui.label("My presets");
            ui.horizontal_wrapped(|ui| {
                for path in personal {
                    let name = path.file_stem().unwrap_or_default().to_string_lossy();
                    if ui.small_button(name).clicked() {
                        match std::fs::read_to_string(&path) { Ok(text) if self.engine.load_json(&text) => {}, _ => self.error = format!("Could not load {}", path.display()) }
                    }
                }
            });
        }
        ui.separator();
        egui::ScrollArea::vertical().show(ui, |ui| {
            for info in self.setting_infos.clone() {
                if matches!(&info.kind, ControlKind::Group) {
                    ui.separator();
                    ui.strong(&info.label);
                    if !info.description.is_empty() { ui.small(&info.description); }
                    continue;
                }
                ui.add_space((info.depth * 2) as f32);
                let mut value = self.engine.value(info.index);
                let changed = match &info.kind {
                    ControlKind::Bool | ControlKind::Group => { let mut checked = value >= 0.5; let r = ui.checkbox(&mut checked, &info.label).on_hover_text(&info.description); value = checked as u8 as f64; r.changed() }
                    ControlKind::Float(min, max) => ui.add(egui::Slider::new(&mut value, *min..=*max).text(&info.label)).on_hover_text(&info.description).changed(),
                    ControlKind::Int(min, max) => ui.add(egui::Slider::new(&mut value, *min as f64..=*max as f64).integer().text(&info.label)).on_hover_text(&info.description).changed(),
                    ControlKind::Enum(options) => {
                        let before = value;
                        egui::ComboBox::from_label(&info.label).selected_text(options.iter().find(|(_, v)| *v as f64 == value).map(|v| v.0.as_str()).unwrap_or("—")).show_ui(ui, |ui| {
                            for (label, option) in options { ui.selectable_value(&mut value, *option as f64, label); }
                        }); before != value
                    }
                };
                if changed { self.engine.set_value(info.index, value); }
            }
        });
    }

    fn shader_effects_ui(&mut self, ui: &mut egui::Ui) {
        if self.shader_root.is_none() {
            ui.colored_label(egui::Color32::RED, "The slang-shaders folder is missing beside NTSC Player.exe");
            return;
        }
        egui::ComboBox::from_label("Shader input resolution")
            .selected_text(match self.shader_input { ShaderInputMode::Source => "Source resolution", ShaderInputMode::Sd480 => "SD · 480 lines", ShaderInputMode::Retro240 => "Retro · 240 lines" })
            .show_ui(ui, |ui| {
                ui.selectable_value(&mut self.shader_input, ShaderInputMode::Source, "Source resolution");
                ui.selectable_value(&mut self.shader_input, ShaderInputMode::Sd480, "SD · 480 lines");
                ui.selectable_value(&mut self.shader_input, ShaderInputMode::Retro240, "Retro · 240 lines");
            });
        ui.checkbox(&mut self.shader_integer_scale, "Integer-scale shader output");
        ui.horizontal_wrapped(|ui| {
            if ui.button("Reset parameters").clicked() && let Some(shader) = &mut self.shader { shader.reset(); }
            if ui.button("Load external…").clicked() && let Some(path) = rfd::FileDialog::new().set_directory(personal_preset_directory("Shaders")).add_filter("RetroArch preset", &["slangp"]).pick_file() { self.load_shader(path); }
            if ui.button("Save preset…").clicked()
                && let Some(text) = self.shader.as_ref().and_then(ShaderEngine::user_preset_text)
                && let Some(path) = rfd::FileDialog::new().set_directory(personal_preset_directory("Shaders")).add_filter("RetroArch preset", &["slangp"]).set_file_name("My Shader.slangp").save_file() {
                    if let Err(error) = std::fs::write(&path, text) { self.error = error.to_string(); }
                    else if !self.shader_presets.contains(&path) { self.shader_presets.push(path); }
                }
        });
        ui.label("Stock presets");
        ui.horizontal_wrapped(|ui| {
            for (index, (name, _)) in shader::STOCK_PRESETS.iter().enumerate() {
                if ui.small_button(*name).clicked() && let Some(path) = self.stock_shader_path(index) { self.load_shader(path); }
            }
        });
        ui.separator();
        ui.label(format!("Shader library ({} presets)", self.shader_presets.len()));
        ui.add(egui::TextEdit::singleline(&mut self.shader_filter).hint_text("Filter shaders…"));
        let needle = self.shader_filter.to_lowercase();
        let root = self.shader_root.clone().expect("checked above");
        let matching: Vec<usize> = self.shader_presets.iter().enumerate()
            .filter(|(_, path)| needle.is_empty() || shader::display_path(&root, path).to_lowercase().contains(&needle))
            .map(|(index, _)| index).collect();
        let mut load = None;
        egui::ScrollArea::vertical().id_salt("shader-library").max_height(260.0).show_rows(ui, 20.0, matching.len(), |ui, rows| {
            for row in rows {
                let path = &self.shader_presets[matching[row]];
                let selected = self.shader_preset.as_ref() == Some(path);
                if ui.selectable_label(selected, shader::display_path(&root, path)).clicked() { load = Some(path.clone()); }
            }
        });
        if let Some(path) = load { self.load_shader(path); }
        ui.separator();
        ui.strong("Shader parameters");
        let loaded_name = self.shader.as_ref().and_then(ShaderEngine::loaded_preset)
            .map(|path| shader::display_path(&root, path)).unwrap_or_else(|| "No shader loaded".into());
        ui.label(loaded_name);
        let parameters: Vec<ShaderParameter> = self.shader.as_ref().map(|shader| shader.parameters().to_vec()).unwrap_or_default();
        egui::ScrollArea::vertical().id_salt("shader-parameters").show(ui, |ui| {
            for (index, parameter) in parameters.iter().enumerate() {
                let Some(shader) = &mut self.shader else { break };
                let mut value = shader.value(index);
                let step = parameter.step.max(0.000_001) as f64;
                if ui.add(egui::Slider::new(&mut value, parameter.minimum..=parameter.maximum).step_by(step).text(&parameter.description))
                    .on_hover_text(&parameter.name).changed() { shader.set_value(index, value); }
            }
        });
    }

    fn jellyfin_ui(&mut self, ctx: &egui::Context) {
        let mut open = self.show_jellyfin;
        egui::Window::new("Jellyfin Library").open(&mut open).default_size([1100.0, 650.0]).show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label("Server"); ui.text_edit_singleline(&mut self.server);
                ui.label("User"); ui.text_edit_singleline(&mut self.username);
                ui.add(egui::TextEdit::singleline(&mut self.password).password(true).hint_text("Password"));
                if ui.button("Connect").clicked() { self.connect_jellyfin(); }
            });
            let mut reload_requested = false;
            let mut reset_search_scroll = false;
            ui.horizontal(|ui| {
                if ui.button("Back").clicked() && !self.navigation.is_empty() { self.navigation.pop(); self.load_children(); }
                egui::ComboBox::from_id_salt("library").selected_text(self.libraries.iter().find(|i| Some(&i.Id) == self.library_id.as_ref()).map(|i| i.Name.as_str()).unwrap_or("Library")).show_ui(ui, |ui| {
                    let libs = self.libraries.clone(); for library in libs { if ui.selectable_label(Some(&library.Id) == self.library_id.as_ref(), &library.Name).clicked() { self.library_id = Some(library.Id); self.navigation.clear(); self.load_children(); } }
                });
                let search_response = ui.add_sized([240.0, 24.0], egui::TextEdit::singleline(&mut self.search).hint_text("Search"));
                if self.focus_jellyfin_search { search_response.request_focus(); self.focus_jellyfin_search = false; }
                if search_response.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) { reload_requested = true; reset_search_scroll = true; }
                if ui.button("Search").clicked() { reload_requested = true; reset_search_scroll = true; }
                let old_sort = self.sort.clone();
                egui::ComboBox::from_id_salt("sort").selected_text(&self.sort).show_ui(ui, |ui| {
                    for (label, value) in [("Name", "SortName"), ("Date added", "DateCreated"), ("Release date", "PremiereDate"), ("Year", "ProductionYear"), ("Rating", "CommunityRating"), ("Runtime", "Runtime")] { ui.selectable_value(&mut self.sort, value.into(), label); }
                });
                if self.sort != old_sort { reload_requested = true; }
                if ui.checkbox(&mut self.descending, "Descending").changed() { reload_requested = true; }
                let old_filter = self.filter.clone();
                egui::ComboBox::from_id_salt("played-filter").selected_text(&self.filter).show_ui(ui, |ui| {
                    for value in ["All", "Unplayed", "Played"] { ui.selectable_value(&mut self.filter, value.into(), value); }
                });
                if self.filter != old_filter { reload_requested = true; }
            });
            if reload_requested { if reset_search_scroll { self.pending_scroll_restore = Some(0.0); self.selected_item = None; } self.load_children(); }
            let mut breadcrumb_target = None;
            ui.horizontal_wrapped(|ui| {
                if let Some(library) = self.libraries.iter().find(|i| Some(&i.Id) == self.library_id.as_ref()) {
                    if ui.link(&library.Name).on_hover_text(format!("Go to {}", library.Name)).clicked() { breadcrumb_target = Some(0); }
                }
                for (index, item) in self.navigation.iter().enumerate() {
                    ui.label("›");
                    if ui.link(&item.Name).on_hover_text(format!("Go to {}", item.Name)).clicked() { breadcrumb_target = Some(index + 1); }
                }
            });
            if let Some(length) = breadcrumb_target { self.navigation.truncate(length); self.search.clear(); self.load_children(); }
            ui.separator();
            let mut action = None;
            let mut area = egui::ScrollArea::vertical().id_salt(("jellyfin-items", self.current_folder_key.as_deref().unwrap_or("none")));
            if let Some(offset) = self.pending_scroll_restore.take() { area = area.vertical_scroll_offset(offset); }
            let scroll_output = area.show(ui, |ui| {
                for item in &self.items {
                    let title = if item.Type.as_deref() == Some("Episode") { format!("S{:02}E{:02}  {}", item.ParentIndexNumber.unwrap_or(0), item.IndexNumber.unwrap_or(0), item.Name) } else { item.Name.clone() };
                    let quality = item.quality_summary();
                    let mut details = vec![item.Type.clone().unwrap_or_default()];
                    if let Some(year) = item.ProductionYear { details.push(year.to_string()); }
                    if let Some(rating) = item.CommunityRating { details.push(format!("★ {rating:.1}")); }
                    if let Some(ticks) = item.RunTimeTicks { details.push(format!("{} min", ticks / 600_000_000)); }
                    if item.UserData.as_ref().and_then(|u| u.Played) == Some(true) { details.push("✓ Played".into()); }
                    if !quality.is_empty() { details.push(quality); }
                    let label = format!("{title}    {}", details.into_iter().filter(|v| !v.is_empty()).collect::<Vec<_>>().join("    "));
                    let response = ui.selectable_label(self.selected_item.as_ref() == Some(&item.Id), label).on_hover_text(item.quality_details());
                    if response.clicked() { self.selected_item = Some(item.Id.clone()); }
                    if response.double_clicked() { action = Some(item.clone()); }
                }
            });
            self.current_scroll_y = scroll_output.state.offset.y;
            self.capture_browser_position();
            if let Some(item) = action {
                if matches!(item.Type.as_deref(), Some("Movie" | "Episode" | "Video" | "MusicVideo")) { self.play_jellyfin_item(item); }
                else { self.navigation.push(item); self.search.clear(); self.load_children(); }
            }
        });
        self.show_jellyfin = open;
    }

    fn controls(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            if ui.button("Open").clicked() && let Some(path) = rfd::FileDialog::new().pick_file() { self.open_file(path); }
            if ui.button("Jellyfin").clicked() { self.show_jellyfin = true; self.focus_jellyfin_search = true; }
            if let Some(q) = &self.queue {
                if ui.add_enabled(q.index > 0, egui::Button::new("⏮")).on_hover_text("Previous queued item").clicked() { self.previous_episode(); }
            }
            if ui.button("−10").clicked() { self.seek_and_reset_field(-10.0, true); }
            if ui.button(if self.playing { "⏸" } else { "▶" }).on_hover_text(if self.playing { "Pause" } else { "Play" }).clicked() { self.toggle_play(); }
            if ui.button("+10").clicked() { self.seek_and_reset_field(10.0, true); }
            if let Some(q) = &self.queue {
                if ui.add_enabled(q.index + 1 < q.entries.len(), egui::Button::new("⏭")).on_hover_text("Next queued item").clicked() { self.next_episode(); }
            }
            let audio_tracks: Vec<_> = self.media_tracks.iter().filter(|t| t.kind == TrackKind::Audio).cloned().collect();
            let mut selected_audio = audio_tracks.iter().find(|t| t.selected).map(|t| t.id).or_else(|| audio_tracks.first().map(|t| t.id));
            let old_audio = selected_audio;
            egui::ComboBox::from_id_salt("audio-track").width(135.0)
                .selected_text(audio_tracks.iter().find(|t| Some(t.id) == selected_audio).map(|t| format!("Audio: {}", t.display_title())).unwrap_or_else(|| "Audio: None".into()))
                .show_ui(ui, |ui| { for track in &audio_tracks { ui.selectable_value(&mut selected_audio, Some(track.id), track.display_title()); } });
            if selected_audio != old_audio {
                if let Some(id) = selected_audio && let Some(mpv) = &mut self.mpv { mpv.select_audio(id); }
                for track in &mut self.media_tracks { if track.kind == TrackKind::Audio { track.selected = Some(track.id) == selected_audio; } }
            }
            let subtitle_tracks: Vec<_> = self.media_tracks.iter().filter(|t| t.kind == TrackKind::Subtitle).cloned().collect();
            let mut selected_subtitle = subtitle_tracks.iter().find(|t| t.selected).map(|t| t.id);
            let old_subtitle = selected_subtitle;
            egui::ComboBox::from_id_salt("subtitle-track").width(135.0)
                .selected_text(subtitle_tracks.iter().find(|t| Some(t.id) == selected_subtitle).map(|t| format!("Subs: {}", t.display_title())).unwrap_or_else(|| "Subs: Off".into()))
                .show_ui(ui, |ui| {
                    ui.selectable_value(&mut selected_subtitle, None, "Off");
                    for track in &subtitle_tracks { ui.selectable_value(&mut selected_subtitle, Some(track.id), track.display_title()); }
                });
            if selected_subtitle != old_subtitle {
                if let Some(mpv) = &mut self.mpv { mpv.select_subtitle(selected_subtitle); }
                for track in &mut self.media_tracks { if track.kind == TrackKind::Subtitle { track.selected = Some(track.id) == selected_subtitle; } }
            }
            ui.label(&self.title);
            if let Some(mpv) = &self.mpv { ui.small(format!("{:.2} fps", mpv.fps())); }
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui.button("Effects (P)").clicked() { self.show_effects = !self.show_effects; }
                if ui.selectable_label(self.crt_fill, format!("4:3 Fill: {}", if self.crt_fill { "On" } else { "Off" })).on_hover_text("Crop clean video to 4:3 before effects, without stretching the picture").clicked() { self.toggle_crt_fill(); }
                if ui.selectable_label(self.screen_fill, format!("Crop to Fill: {}", if self.screen_fill { "On" } else { "Off" })).on_hover_text("Crop the minimum amount needed to fill the current display").clicked() { self.toggle_screen_fill(); }
                if ui.button("Fullscreen").clicked() { self.toggle_fullscreen(ui.ctx()); }
                if ui.add(egui::Slider::new(&mut self.volume, 0.0..=1.0).show_value(false).text("Volume")).changed() { if let Some(mpv) = &mut self.mpv { mpv.set_volume(self.volume); } }
            });
        });
        let mut scrubbed_to = None;
        if let Some(mpv) = &mut self.mpv {
            let mut time = mpv.time(); let duration = mpv.duration().max(1.0);
            ui.horizontal(|ui| {
                ui.label(format_time(time));
                let width = (ui.available_width() - 72.0).max(160.0);
                ui.spacing_mut().slider_width = width;
                if ui.add(egui::Slider::new(&mut time, 0.0..=duration).show_value(false)).changed() { mpv.seek(time, false); scrubbed_to = Some(time); self.ready_for_eof = false; }
                ui.label(format_time(duration));
            });
        }
        if let Some(time) = scrubbed_to {
            self.ntsc_field_index = self.field_index(time);
            self.mark_still_frame_dirty(Duration::from_millis(350));
        }
    }

    fn toggle_crt_fill(&mut self) {
        self.crt_fill = !self.crt_fill;
        if self.crt_fill { self.screen_fill = false; }
        if let Some(mpv) = &mut self.mpv { mpv.set_crt_fill(self.crt_fill); }
    }

    fn toggle_screen_fill(&mut self) {
        self.screen_fill = !self.screen_fill;
        if self.screen_fill { self.crt_fill = false; if let Some(mpv) = &mut self.mpv { mpv.set_crt_fill(false); } }
    }

    fn toggle_fullscreen(&mut self, ctx: &egui::Context) {
        self.fullscreen = !self.fullscreen;
        self.controls_visible = true;
        self.last_mouse_activity = Instant::now();
        ctx.send_viewport_cmd(egui::ViewportCommand::Fullscreen(self.fullscreen));
    }
}

impl eframe::App for WindowsPlayer {
    fn update(&mut self, ctx: &egui::Context, frame: &mut eframe::Frame) {
        let paused_visual_before = (!self.playing && self.video_open).then(|| self.visual_signature());
        let screen = ctx.screen_rect();
        if screen.height() > 0.0 && self.display_aspect <= 0.0 { self.display_aspect = (screen.width() / screen.height()).max(0.1); }
        for dropped in ctx.input(|i| i.raw.dropped_files.clone()) { if let Some(path) = dropped.path { self.open_file(path); break; } }
        if ctx.input(|i| i.key_pressed(egui::Key::Space) && !i.modifiers.any()) { self.toggle_play(); }
        if ctx.input(|i| i.key_pressed(egui::Key::ArrowLeft)) { self.seek_and_reset_field(-10.0, true); }
        if ctx.input(|i| i.key_pressed(egui::Key::ArrowRight)) { self.seek_and_reset_field(10.0, true); }
        if ctx.input(|i| i.key_pressed(egui::Key::P) && !i.modifiers.any()) { self.show_effects = !self.show_effects; }
        if !ctx.wants_keyboard_input() && ctx.input(|i| i.key_pressed(egui::Key::B) && !i.modifiers.any()) { self.bypass = !self.bypass; }
        if !ctx.wants_keyboard_input() && ctx.input(|i| i.key_pressed(egui::Key::C) && !i.modifiers.any()) { self.toggle_crt_fill(); }
        let global_fullscreen_key = ctx.input(|i| i.key_pressed(egui::Key::F11) || (i.modifiers.alt && i.key_pressed(egui::Key::Enter)));
        let plain_f = !ctx.wants_keyboard_input() && ctx.input(|i| !i.modifiers.any() && i.key_pressed(egui::Key::F));
        if global_fullscreen_key || plain_f { self.toggle_fullscreen(ctx); }
        let pointer = ctx.input(|i| i.pointer.latest_pos());
        if pointer != self.last_mouse { self.last_mouse = pointer; self.last_mouse_activity = Instant::now(); self.controls_visible = true; }
        if self.fullscreen && self.last_mouse_activity.elapsed() > Duration::from_secs(2) { self.controls_visible = false; }
        self.update_video(ctx);
        let mut double_clicked_video = false;
        egui::CentralPanel::default().frame(egui::Frame::NONE.fill(egui::Color32::BLACK)).show(ctx, |ui| {
            let video_area = ui.max_rect();
            if video_area.height() > 0.0 {
                self.display_aspect = (video_area.width() / video_area.height()).max(0.1);
                let scale = ctx.pixels_per_point();
                self.display_pixel_size = (
                    (video_area.width() * scale).round().max(1.0) as usize,
                    (video_area.height() * scale).round().max(1.0) as usize,
                );
            }
            let available = ui.available_size();
            if let Some(texture) = &self.texture {
                let source = texture.size_vec2();
                let uv = egui::Rect::from_min_max(egui::Pos2::ZERO, egui::pos2(1.0, 1.0));
                let visible_aspect = if self.screen_fill { self.display_aspect } else { source.x / source.y };
                let target = if self.effect_mode == EffectMode::Shaders && self.shader_integer_scale { integer_fit_size(available, source) } else { fit_size(available, visible_aspect) };
                let response = ui.centered_and_justified(|ui| ui.add(egui::Image::new(texture).uv(uv).fit_to_exact_size(target).sense(egui::Sense::click()))).inner;
                double_clicked_video = response.double_clicked();
            } else { let response = ui.centered_and_justified(|ui| ui.add(egui::Label::new("Drop a video here").sense(egui::Sense::click()))).inner; double_clicked_video = response.double_clicked(); }
            let surface_response = ui.interact(video_area, ui.id().with("video_surface_double_click"), egui::Sense::click());
            double_clicked_video |= surface_response.double_clicked();
        });
        if double_clicked_video { self.toggle_fullscreen(ctx); }
        if !self.fullscreen || self.controls_visible { egui::TopBottomPanel::bottom("controls").show(ctx, |ui| self.controls(ui)); }
        if self.show_effects { egui::SidePanel::right("effects").resizable(false).default_width(320.0).show(ctx, |ui| self.effects_ui(ui)); }
        if self.show_jellyfin { self.jellyfin_ui(ctx); }
        if !self.error.is_empty() { egui::TopBottomPanel::top("error").show(ctx, |ui| { ui.colored_label(egui::Color32::RED, &self.error); }); }
        if let Some(before) = paused_visual_before {
            if !self.playing && before != self.visual_signature() {
                self.mark_still_frame_dirty(Duration::ZERO);
                ctx.request_repaint();
            }
        }
        if self.last_save.elapsed() >= Duration::from_secs(2) {
            if let Some(storage) = frame.storage_mut() { self.save(storage); storage.flush(); }
            self.last_save = Instant::now();
        }
        let repaint_interval = if !self.playing {
            if self.still_frame_dirty { 0.1 } else { 2.0 }
        } else if self.effect_mode == EffectMode::Ntsc && self.ntsc_field_cadence == NtscFieldCadence::Custom {
            (1.0 / self.ntsc_field_rate).clamp(0.008, 0.016)
        } else { 0.016 };
        ctx.request_repaint_after(Duration::from_secs_f64(repaint_interval));
    }
    fn save(&mut self, storage: &mut dyn eframe::Storage) {
        self.capture_browser_position();
        let client = self.jellyfin.as_ref();
        let navigation = self.library_id.iter().map(|id| (id.clone(), "Library".into(), "CollectionFolder".into()))
            .chain(self.navigation.iter().map(|i| (i.Id.clone(), i.Name.clone(), i.Type.clone().unwrap_or_else(|| "Folder".into())))).collect();
        let state = SavedState {
            server: self.server.clone(), username: self.username.clone(), token: client.map(|c| c.token.clone()).unwrap_or_default(), user_id: client.map(|c| c.user_id.clone()).unwrap_or_default(),
            library_id: self.library_id.clone(), navigation, last_url: self.current_url.clone(), last_title: self.title.clone(),
            last_position: self.mpv.as_ref().map(Mpv::time).unwrap_or(self.last_playhead), was_playing: self.playing, queue: self.queue.clone(), volume: self.volume,
            crt_fill: self.crt_fill, screen_fill: self.screen_fill, effect_mode: self.effect_mode,
            ntsc_field_cadence: Some(match self.ntsc_field_cadence { NtscFieldCadence::Frame => 0, NtscFieldCadence::Fields => 1, NtscFieldCadence::Custom => 2 }),
            ntsc_field_rate: Some(self.ntsc_field_rate),
            ntsc_state: self.engine.json(),
            shader_preset: self.shader_preset.as_ref().map(|path| path.to_string_lossy().to_string()),
            shader_values: self.shader.as_ref().map(|shader| shader.parameters().iter().enumerate().map(|(index, _)| shader.value(index)).collect()).unwrap_or_default(),
            master_brightness: Some(self.master_brightness), ntsc_resolution: self.ntsc_resolution,
            shader_input: self.shader_input, shader_integer_scale: self.shader_integer_scale, bypass: self.bypass,
            search: self.search.clone(), descending: self.descending, sort: self.sort.clone(), filter: self.filter.clone(),
            folder_states: self.folder_states.clone(),
        };
        eframe::set_value(storage, STATE_KEY, &state);
    }
}

impl Drop for WindowsPlayer { fn drop(&mut self) { sleep::set_playing(false); } }

fn organize(items: Vec<Item>, parent: Option<&str>) -> Vec<Item> {
    if parent == Some("Season") { return items; }
    let episodes: Vec<_> = items.iter().filter(|i| i.Type.as_deref() == Some("Episode")).cloned().collect();
    if episodes.is_empty() { return items; }
    let mut folders = std::collections::BTreeMap::new();
    for episode in episodes {
        let (id, name, kind) = if parent == Some("Series") {
            (episode.SeasonId.clone(), episode.SeasonName.clone().unwrap_or_else(|| format!("Season {}", episode.ParentIndexNumber.unwrap_or(0))), "Season")
        } else {
            (episode.SeriesId.clone(), episode.SeriesName.clone().unwrap_or_else(|| "Series".into()), "Series")
        };
        if let Some(id) = id { folders.entry(id.clone()).or_insert(Item { Id: id, Name: name, Type: Some(kind.into()), ..Default::default() }); }
    }
    let mut result: Vec<_> = items.into_iter().filter(|i| i.Type.as_deref() != Some("Episode")).collect(); result.extend(folders.into_values()); result
}

fn is_playable_item(item: &Item) -> bool {
    matches!(item.Type.as_deref(), Some("Movie" | "Episode" | "Video" | "MusicVideo"))
}

fn should_queue_current_folder(collection_type: Option<&str>, search: &str) -> bool {
    search.trim().is_empty()
        && !matches!(collection_type.map(str::to_ascii_lowercase).as_deref(), Some("tvshows" | "movies"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn custom_field_rate_accepts_precise_decimals_and_fractions() {
        assert_eq!(parse_field_rate("59.94"), Some(59.94));
        assert_eq!(parse_field_rate("60000/1001"), Some(60_000.0 / 1_001.0));
        assert_eq!(parse_field_rate("15"), Some(15.0));
        assert_eq!(parse_field_rate("120"), Some(120.0));
        for bad in ["", "14.99", "120.01", "0/0", "60000/0", "1/2/3", "NaN", "inf"] {
            assert_eq!(parse_field_rate(bad), None, "unexpectedly accepted {bad}");
        }
    }

    #[test]
    fn only_non_tv_non_movie_folders_become_queues() {
        assert!(should_queue_current_folder(Some("homevideos"), ""));
        assert!(should_queue_current_folder(Some("musicvideos"), ""));
        assert!(!should_queue_current_folder(Some("tvshows"), ""));
        assert!(!should_queue_current_folder(Some("movies"), ""));
        assert!(!should_queue_current_folder(Some("homevideos"), "Sopranos"));
    }

    #[test]
    fn folder_queue_filters_non_playable_items_without_reordering() {
        let items = [
            Item { Id: "folder".into(), Name: "Folder".into(), Type: Some("Folder".into()), ..Default::default() },
            Item { Id: "second".into(), Name: "Second".into(), Type: Some("Video".into()), ..Default::default() },
            Item { Id: "first".into(), Name: "First".into(), Type: Some("Episode".into()), ..Default::default() },
        ];
        let ids: Vec<_> = items.iter().filter(|item| is_playable_item(item)).map(|item| item.Id.as_str()).collect();
        assert_eq!(ids, ["second", "first"]);
    }

    #[test]
    fn crop_changes_picture_geometry_without_zooming_effect_pixels() {
        let source = (1920, 1080);
        let viewport = (1440, 1080);
        let normal = effect_raster_size(source.0, source.1, viewport.0, viewport.1, source.0, source.1);
        let cropped = effect_raster_size(1440, 1080, viewport.0, viewport.1, source.0, source.1);
        assert_eq!(normal, (1440, 810));
        assert_eq!(cropped, (1440, 1080));

        let widescreen_viewport = (1920, 1200);
        let normal = effect_raster_size(source.0, source.1, widescreen_viewport.0, widescreen_viewport.1, source.0, source.1);
        let cropped = effect_raster_size(1728, 1080, widescreen_viewport.0, widescreen_viewport.1, source.0, source.1);
        assert_eq!(normal, (1728, 972));
        assert_eq!(cropped, (1728, 1080));
    }

    #[test]
    fn clean_frame_is_resized_before_effects() {
        // Distinct columns prove that crop/resize uses clean source samples.
        let pixels = [0, 0, 0, 0, 40, 40, 40, 0, 80, 80, 80, 0, 120, 120, 120, 0];
        let (cropped, width, height) = crop_bgr0(&pixels, 4, 1, 2.0);
        assert_eq!((width, height), (2, 1));
        assert_eq!(&cropped[..4], &[40, 40, 40, 0]);
        assert_eq!(&cropped[4..], &[80, 80, 80, 0]);
        let resized = resize_bgr0(&cropped, width, height, 4, 1);
        assert_eq!(resized.len(), 16);
        assert_eq!(resized[0], 40);
        assert_eq!(resized[12], 80);
    }
}
fn format_time(seconds: f64) -> String { let n = seconds.max(0.0) as u64; if n >= 3600 { format!("{}:{:02}:{:02}", n / 3600, n / 60 % 60, n % 60) } else { format!("{}:{:02}", n / 60, n % 60) } }

fn parse_field_rate(input: &str) -> Option<f64> {
    let trimmed = input.trim();
    let rate = if let Some((numerator, denominator)) = trimmed.split_once('/') {
        let numerator = numerator.trim().parse::<f64>().ok()?;
        let denominator = denominator.trim().parse::<f64>().ok()?;
        if denominator == 0.0 { return None; }
        numerator / denominator
    } else { trimmed.parse::<f64>().ok()? };
    (rate.is_finite() && (15.0..=120.0).contains(&rate)).then_some(rate)
}

fn bgr0_to_rgba(pixels: &mut [u8]) {
    for pixel in pixels.chunks_exact_mut(4) { pixel.swap(0, 2); pixel[3] = 255; }
}

fn is_english_track(track: &MediaTrack) -> bool {
    let language = track.language.trim().to_ascii_lowercase();
    language == "en" || language == "eng" || language.starts_with("en-") || language.starts_with("en_") ||
        track.title.to_ascii_lowercase().contains("english")
}

fn crop_bgr0(pixels: &[u8], width: usize, height: usize, target_aspect: f32) -> (Vec<u8>, usize, usize) {
    if width == 0 || height == 0 || target_aspect <= 0.0 { return (pixels.to_vec(), width, height); }
    let source_aspect = width as f32 / height as f32;
    let (crop_width, crop_height) = if source_aspect > target_aspect {
        (((height as f32 * target_aspect).round() as usize).clamp(1, width), height)
    } else {
        (width, ((width as f32 / target_aspect).round() as usize).clamp(1, height))
    };
    if crop_width == width && crop_height == height { return (pixels.to_vec(), width, height); }
    let left = (width - crop_width) / 2;
    let top = (height - crop_height) / 2;
    let mut result = vec![0; crop_width * crop_height * 4];
    for row in 0..crop_height {
        let source_start = ((top + row) * width + left) * 4;
        let target_start = row * crop_width * 4;
        result[target_start..target_start + crop_width * 4].copy_from_slice(&pixels[source_start..source_start + crop_width * 4]);
    }
    (result, crop_width, crop_height)
}

fn effect_raster_size(
    width: usize, height: usize, viewport_width: usize, viewport_height: usize,
    source_width: usize, source_height: usize,
) -> (usize, usize) {
    if width == 0 || height == 0 || viewport_width == 0 || viewport_height == 0 {
        return (width, height);
    }
    // Use the *uncropped* frame as a fixed cap; otherwise crop changes the
    // raster density, making noise, masks, and scanlines appear to zoom.
    let scale = 1.0_f64
        .min(source_width as f64 / viewport_width as f64)
        .min(source_height as f64 / viewport_height as f64);
    let canvas_width = (viewport_width as f64 * scale).max(1.0);
    let canvas_height = (viewport_height as f64 * scale).max(1.0);
    let fit = (canvas_width / width as f64).min(canvas_height / height as f64);
    ((width as f64 * fit).round().max(1.0) as usize,
     (height as f64 * fit).round().max(1.0) as usize)
}

fn resize_bgr0(pixels: &[u8], width: usize, height: usize, output_width: usize, output_height: usize) -> Vec<u8> {
    if (width, height) == (output_width, output_height) { return pixels.to_vec(); }
    let mut output = vec![0_u8; output_width * output_height * 4];
    let columns: Vec<(usize, usize, f32)> = (0..output_width).map(|x| {
        let source_x = ((x as f32 + 0.5) * width as f32 / output_width as f32 - 0.5).max(0.0);
        let left = (source_x.floor() as usize).min(width - 1);
        (left, (left + 1).min(width - 1), source_x - left as f32)
    }).collect();
    output.par_chunks_mut(output_width * 4).enumerate().for_each(|(y, row)| {
        let source_y = ((y as f32 + 0.5) * height as f32 / output_height as f32 - 0.5).max(0.0);
        let top = (source_y.floor() as usize).min(height - 1);
        let bottom = (top + 1).min(height - 1);
        let fy = source_y - top as f32;
        for (x, &(left, right, fx)) in columns.iter().enumerate() {
            let top_left = (top * width + left) * 4;
            let top_right = (top * width + right) * 4;
            let bottom_left = (bottom * width + left) * 4;
            let bottom_right = (bottom * width + right) * 4;
            for channel in 0..4 {
                let upper = pixels[top_left + channel] as f32 * (1.0 - fx) + pixels[top_right + channel] as f32 * fx;
                let lower = pixels[bottom_left + channel] as f32 * (1.0 - fx) + pixels[bottom_right + channel] as f32 * fx;
                row[x * 4 + channel] = (upper * (1.0 - fy) + lower * fy).round() as u8;
            }
        }
    });
    output
}

fn apply_master_brightness(pixels: &mut [u8], brightness: f32) {
    let brightness = brightness.clamp(0.0, 1.1);
    for pixel in pixels.chunks_exact_mut(4) {
        for channel in &mut pixel[..3] {
            let value = *channel as f32;
            *channel = if brightness <= 1.0 { (value * brightness).round() as u8 }
                else { (value + (255.0 - value) * (brightness - 1.0)).round().clamp(0.0, 255.0) as u8 };
        }
    }
}

fn fit_size(available: egui::Vec2, aspect: f32) -> egui::Vec2 {
    if available.x / available.y > aspect { egui::vec2(available.y * aspect, available.y) }
    else { egui::vec2(available.x, available.x / aspect) }
}


fn integer_fit_size(available: egui::Vec2, source: egui::Vec2) -> egui::Vec2 {
    let factor = (available.x / source.x).min(available.y / source.y).floor();
    if factor >= 1.0 { source * factor } else { fit_size(available, source.x / source.y) }
}

fn personal_preset_directory(kind: &str) -> PathBuf {
    let base = std::env::var_os("APPDATA").map(PathBuf::from)
        .or_else(|| std::env::current_dir().ok()).unwrap_or_else(|| PathBuf::from("."));
    let path = base.join("NTSC Player").join("Presets").join(kind);
    let _ = std::fs::create_dir_all(&path);
    path
}

fn discover_personal_presets(kind: &str, extension: &str) -> Vec<PathBuf> {
    let mut result: Vec<_> = std::fs::read_dir(personal_preset_directory(kind)).into_iter().flatten().flatten()
        .map(|entry| entry.path()).filter(|path| path.extension().is_some_and(|ext| ext.eq_ignore_ascii_case(extension))).collect();
    result.sort_by_cached_key(|path| path.to_string_lossy().to_lowercase());
    result
}

fn main() -> eframe::Result {
    let options = eframe::NativeOptions { viewport: egui::ViewportBuilder::default().with_title("NTSC Player").with_inner_size([1120.0, 700.0]).with_drag_and_drop(true), ..Default::default() };
    eframe::run_native("NTSC Player", options, Box::new(|cc| Ok(Box::new(WindowsPlayer::new(cc)))))
}
