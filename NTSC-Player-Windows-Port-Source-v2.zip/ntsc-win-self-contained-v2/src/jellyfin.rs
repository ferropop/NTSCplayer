use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};
use url::Url;

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[allow(non_snake_case)]
pub struct Item {
    pub Id: String,
    pub Name: String,
    pub Type: Option<String>,
    pub CollectionType: Option<String>,
    pub ParentId: Option<String>,
    pub IndexNumber: Option<i32>,
    pub ParentIndexNumber: Option<i32>,
    pub SeriesId: Option<String>,
    pub SeasonId: Option<String>,
    pub ProductionYear: Option<i32>,
}

#[derive(Clone, Debug, Deserialize)]
#[allow(non_snake_case)]
struct Items { Items: Option<Vec<Item>> }

#[derive(Deserialize)]
#[allow(non_snake_case)]
struct Authentication { AccessToken: String, User: User }
#[derive(Deserialize)]
#[allow(non_snake_case)]
struct User { Id: String }

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct QueueEntry { pub item_id: String, pub title: String, pub url: Url }
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PlaybackQueue { pub entries: Vec<QueueEntry>, pub index: usize }

#[derive(Clone)]
pub struct Jellyfin {
    pub server: Url,
    pub token: String,
    pub user_id: String,
    client: Client,
}

impl Jellyfin {
    pub fn login(server: &str, username: &str, password: &str) -> Result<Self, String> {
        let server = normalize(server)?;
        let client = Client::builder().build().map_err(|e| e.to_string())?;
        let url = server.join("Users/AuthenticateByName").map_err(|e| e.to_string())?;
        let response = client.post(url)
            .header("Authorization", auth_header(""))
            .json(&serde_json::json!({"Username": username, "Pw": password}))
            .send().map_err(|e| e.to_string())?;
        if !response.status().is_success() { return Err(format!("Jellyfin returned HTTP {}", response.status())); }
        let auth: Authentication = response.json().map_err(|e| e.to_string())?;
        Ok(Self { server, token: auth.AccessToken, user_id: auth.User.Id, client })
    }
    pub fn from_token(server: &str, token: String, user_id: String) -> Result<Self, String> {
        Ok(Self { server: normalize(server)?, token, user_id, client: Client::new() })
    }
    pub fn libraries(&self) -> Result<Vec<Item>, String> { self.get(&format!("Users/{}/Views", self.user_id), &[]) }
    pub fn children(&self, parent: &str, search: &str, sort: &str, descending: bool) -> Result<Vec<Item>, String> {
        let mut query = vec![
            ("ParentId", parent.to_string()), ("Recursive", (!search.is_empty()).to_string()),
            ("IncludeItemTypes", "Movie,Series,Season,Episode,Video,MusicVideo,Folder,BoxSet".into()),
            ("Fields", "ParentId,IndexNumber,ParentIndexNumber,SeriesId,SeasonId,ProductionYear".into()),
            ("SortBy", sort.into()), ("SortOrder", if descending { "Descending" } else { "Ascending" }.into()),
            ("Limit", "1000".into()),
        ];
        if !search.is_empty() { query.push(("SearchTerm", search.into())); }
        self.get(&format!("Users/{}/Items", self.user_id), &query)
    }
    pub fn series_queue(&self, selected: &Item) -> Result<PlaybackQueue, String> {
        let parent = selected.SeriesId.as_deref().or(selected.ParentId.as_deref()).ok_or("Episode has no series ID")?;
        let query = vec![
            ("ParentId", parent.to_string()), ("Recursive", "true".into()),
            ("IncludeItemTypes", "Episode".into()),
            ("Fields", "ParentId,IndexNumber,ParentIndexNumber,SeriesId,SeasonId".into()),
            ("Limit", "1000".into()),
        ];
        let mut episodes: Vec<Item> = self.get(&format!("Users/{}/Items", self.user_id), &query)?;
        episodes.sort_by_key(|e| (e.ParentIndexNumber.unwrap_or(0), e.IndexNumber.unwrap_or(0), e.Name.clone()));
        let entries: Vec<_> = episodes.iter().map(|e| QueueEntry { item_id: e.Id.clone(), title: e.Name.clone(), url: self.stream_url(&e.Id) }).collect();
        let index = entries.iter().position(|e| e.item_id == selected.Id).unwrap_or(0);
        Ok(PlaybackQueue { entries, index })
    }
    pub fn stream_url(&self, id: &str) -> Url {
        let mut url = self.server.join(&format!("Videos/{id}/stream")).unwrap();
        url.query_pairs_mut().append_pair("Static", "true").append_pair("api_key", &self.token);
        url
    }
    fn get(&self, path: &str, query: &[(&str, String)]) -> Result<Vec<Item>, String> {
        let url = self.server.join(path).map_err(|e| e.to_string())?;
        let query: Vec<_> = query.iter().map(|(k, v)| (*k, v.as_str())).collect();
        let response = self.client.get(url).query(&query).header("Authorization", auth_header(&self.token)).header("X-Emby-Token", &self.token).send().map_err(|e| e.to_string())?;
        if !response.status().is_success() { return Err(format!("Jellyfin returned HTTP {}", response.status())); }
        Ok(response.json::<Items>().map_err(|e| e.to_string())?.Items.unwrap_or_default())
    }
}

fn normalize(value: &str) -> Result<Url, String> {
    let mut text = value.trim().to_string();
    if !text.contains("://") { text = format!("http://{text}"); }
    if !text.ends_with('/') { text.push('/'); }
    Url::parse(&text).map_err(|e| e.to_string())
}
fn auth_header(token: &str) -> String {
    format!("MediaBrowser Client=\"NTSC%20Player\", Device=\"Windows\", DeviceId=\"ntsc-player-windows\", Version=\"0.1.0\", Token=\"{token}\"")
}
