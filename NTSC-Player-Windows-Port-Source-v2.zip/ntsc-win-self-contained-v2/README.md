# NTSC Player for Windows

Native Windows 10/11 x64 port of the macOS NTSC Player. It decodes and plays audio
through libmpv, processes displayed frames through the same vendored `ntsc-rs` core,
and renders through wgpu/Direct3D 12.

## Included

- Local files, mounted SMB/Samba paths, HTTP streams, and drag-and-drop
- Play/pause, ±10 seconds, timeline, volume, and fullscreen
- Full ntsc-rs parameter list with live controls and JSON preset import/export
- The identical aggressive standalone saved-settings default used by the macOS build
- Jellyfin login, libraries, hierarchical Show → Season → Episode browsing, search, and sorting
- Full-series Previous/Next Episode queue with automatic advancement across seasons
- Last video, queue, Jellyfin navigation, volume, and playback position persistence
- Fullscreen controls that appear with mouse movement and hide after two seconds
- P toggles the interactive effect panel
- Windows display/system sleep blocking only while video is actively playing

The saved session is restored paused at its previous position. Press Space to continue.

## Build on Windows

Requirements:

1. Windows 10 or 11 x64
2. Stable x64 MSVC Rust from <https://rustup.rs>
3. Visual Studio 2022 Build Tools with **Desktop development with C++**
4. A 64-bit `mpv-2.dll`/libmpv build

PowerShell:

```powershell
.\build-windows.ps1 -MpvDll C:\path\to\mpv-2.dll
```

The portable archive is written to `dist\NTSC-Player-Windows-x64.zip`. Keep
`mpv-2.dll` beside `NTSC Player.exe`.

The repository is self-contained: the exact ntsc-rs revision used by the macOS
player is vendored under `vendor\ntsc-rs-source`, so cloning this one repository
is sufficient.

## Keyboard

- Space: play/pause
- Left/Right: seek 10 seconds
- F11: fullscreen
- P: effect controls

## Current shader status

The Windows frontend currently ships the complete ntsc-rs engine and preset controls.
The RetroArch Slang/librashader engine is intentionally not exposed in this first
Windows package yet: the macOS Metal renderer cannot be reused, and the Windows port
needs a native D3D11/D3D12 texture path rather than a CPU readback implementation.
