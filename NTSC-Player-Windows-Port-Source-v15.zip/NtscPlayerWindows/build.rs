fn main() {
    #[cfg(windows)]
    {
        let mut resource = winres::WindowsResource::new();
        resource.set_icon("resources/NTSCPlayer.ico");
        resource.compile().expect("failed to embed NTSC Player icon");
    }
}
