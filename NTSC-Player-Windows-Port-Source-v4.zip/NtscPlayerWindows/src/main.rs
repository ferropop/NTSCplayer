#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]

mod jellyfin;
mod mpv;
mod ntsc;
mod shader;
mod sleep;

use eframe::egui;
use jellyfin::{Item, Jellyfin, PlaybackQueue};
use mpv::Mpv;
use ntsc::{ControlKind, Engine, SettingInfo};
use shader::{ShaderEngine, ShaderParameter};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::time::{Duration, Instant};

const STATE_KEY: &str = "ntsc-player-windows-state-v1";

#[derive(Clone, Deserialize)]
struct NtscStockPreset {
    name: String,
    json: String,
    credit: String,
}

#[derive(Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
enum EffectMode {
    #[default]
    Ntsc,
    Shaders,
}

#[derive(Default, Serialize, Deserialize)]
#[serde(default)]
struct SavedState {
    server: String,
    username: String,
    token: String,
    user_id: String,
    library_id: Option<String>,
    navigation: Vec<(String, String, String)>,
    last_url: Option<String>,
    last_title: String,
    last_position: f64,
    queue: Option<PlaybackQueue>,
    volume: f64,
    crt_fill: bool,
    effect_mode: EffectMode,
    shader_preset: Option<String>,
}

struct WindowsPlayer {
    mpv: Option<Mpv>,
    engine: Engine,
    setting_infos: Vec<SettingInfo>,
    effect_mode: EffectMode,
    shader: Option<ShaderEngine>,
    shader_root: Option<PathBuf>,
    shader_presets: Vec<PathBuf>,
    shader_filter: String,
    shader_preset: Option<PathBuf>,
    ntsc_stock_presets: Vec<NtscStockPreset>,
    texture: Option<egui::TextureHandle>,
    video_open: bool,
    current_url: Option<String>,
    title: String,
    playing: bool,
    ready_for_eof: bool,
    resume_at: Option<f64>,
    queue: Option<PlaybackQueue>,
    volume: f64,
    bypass: bool,
    crt_fill: bool,
    show_effects: bool,
    fullscreen: bool,
    controls_visible: bool,
    last_mouse: Option<egui::Pos2>,
    last_mouse_activity: Instant,
    sleep_blocked: bool,
    error: String,
    server: String,
    username: String,
    password: String,
    jellyfin: Option<Jellyfin>,
    show_jellyfin: bool,
    libraries: Vec<Item>,
    library_id: Option<String>,
    navigation: Vec<Item>,
    items: Vec<Item>,
    selected_item: Option<String>,
    search: String,
    descending: bool,
    sort: String,
    last_save: Instant,
}

impl WindowsPlayer {
    fn new(cc: &eframe::CreationContext<'_>) -> Self {
        let saved: SavedState = cc.storage.and_then(|s| eframe::get_value(s, STATE_KEY)).unwrap_or_default();
        let mut app = Self {
            mpv: Mpv::new().map_err(|e| e.to_string()).ok(), engine: Engine::new(), setting_infos: Engine::settings(),
            effect_mode: saved.effect_mode, shader: None, shader_root: shader::shader_root(), shader_presets: Vec::new(),
            shader_filter: String::new(), shader_preset: saved.shader_preset.map(PathBuf::from),
            ntsc_stock_presets: serde_json::from_str(include_str!("../resources/ntsc-stock-presets.json")).unwrap_or_default(),
            texture: None, video_open: false, current_url: None, title: "Drop a video here".into(), playing: false,
            ready_for_eof: false, resume_at: None, queue: None, volume: if saved.volume > 0.0 { saved.volume } else { 0.85 },
            bypass: false, crt_fill: saved.crt_fill, show_effects: false, fullscreen: false, controls_visible: true, last_mouse: None,
            last_mouse_activity: Instant::now(), sleep_blocked: false, error: String::new(),
            server: if saved.server.is_empty() { "http://localhost:8096".into() } else { saved.server.clone() },
            username: saved.username.clone(), password: String::new(), jellyfin: None, show_jellyfin: false,
            libraries: Vec::new(), library_id: saved.library_id.clone(), navigation: Vec::new(), items: Vec::new(),
            selected_item: None, search: String::new(), descending: false, sort: "SortName".into(), last_save: Instant::now(),
        };
        if let Some(root) = &app.shader_root { app.shader_presets = shader::discover_presets(root); }
        if app.effect_mode == EffectMode::Shaders {
            let preset = app.shader_preset.clone().or_else(|| app.stock_shader_path(0));
            if let Some(path) = preset { app.load_shader(path); }
        }
        if let Some(mpv) = &mut app.mpv { mpv.set_volume(app.volume); }
        if !saved.token.is_empty() {
            if let Ok(client) = Jellyfin::from_token(&saved.server, saved.token, saved.user_id) {
                app.jellyfin = Some(client);
                app.load_libraries();
                app.restore_navigation(saved.navigation);
            }
        }
        if let Some(url) = saved.last_url { app.open_source(url, saved.last_title, saved.queue, Some(saved.last_position), false); }
        if app.mpv.is_none() { app.error = "mpv-2.dll is missing. Put it beside NTSC Player.exe.".into(); }
        app
    }

    fn open_source(&mut self, source: String, title: String, queue: Option<PlaybackQueue>, resume: Option<f64>, autoplay: bool) {
        let Some(mpv) = &mut self.mpv else { return };
        match mpv.load(&source) {
            Ok(()) => {
                self.current_url = Some(source); self.title = title; self.queue = queue; self.video_open = true;
                self.resume_at = resume.filter(|v| *v > 0.0); self.playing = autoplay; self.ready_for_eof = false;
                mpv.set_paused(!autoplay); mpv.set_volume(self.volume);
                self.error.clear(); self.sync_sleep();
            }
            Err(e) => self.error = e,
        }
    }
    fn open_file(&mut self, path: PathBuf) { self.open_source(path.to_string_lossy().to_string(), path.file_name().unwrap_or_default().to_string_lossy().to_string(), None, None, true); }
    fn toggle_play(&mut self) {
        if !self.video_open { if let Some(path) = rfd::FileDialog::new().pick_file() { self.open_file(path); } return; }
        self.playing = !self.playing;
        if let Some(mpv) = &mut self.mpv {
            if self.playing && mpv.eof() { mpv.seek(0.0, false); self.ready_for_eof = false; }
            mpv.set_paused(!self.playing);
        }
        self.sync_sleep();
    }
    fn play_queue_index(&mut self, index: usize) {
        let Some(mut queue) = self.queue.clone() else { return };
        let Some(entry) = queue.entries.get(index).cloned() else { return };
        queue.index = index;
        self.open_source(entry.url.to_string(), entry.title, Some(queue), None, true);
    }
    fn previous_episode(&mut self) { if let Some(q) = &self.queue && q.index > 0 { self.play_queue_index(q.index - 1); } }
    fn next_episode(&mut self) { if let Some(q) = &self.queue && q.index + 1 < q.entries.len() { self.play_queue_index(q.index + 1); } }
    fn sync_sleep(&mut self) {
        let should = self.playing && self.video_open;
        if should != self.sleep_blocked { sleep::set_playing(should); self.sleep_blocked = should; }
    }
    fn update_video(&mut self, ctx: &egui::Context) {
        if !self.video_open { return; }
        let reached_end = {
            let Some(mpv) = &mut self.mpv else { return };
            let duration = mpv.duration();
            if duration > 0.0 {
                if let Some(position) = self.resume_at.take() { mpv.seek(position.min((duration - 0.05).max(0.0)), false); }
                if !mpv.eof() { self.ready_for_eof = true; }
            }
            self.ready_for_eof && mpv.eof() && self.playing
        };
        if reached_end {
            if let Some(q) = &self.queue && q.index + 1 < q.entries.len() { self.next_episode(); return; }
            self.playing = false;
            if let Some(mpv) = &mut self.mpv { mpv.set_paused(true); }
            self.sync_sleep();
        }
        let Some(mpv) = &mut self.mpv else { return };
        let Some((mut width, mut height)) = mpv.size() else { return };
        let scale = (1920.0 / width as f32).min(1080.0 / height as f32).min(1.0);
        width = (width as f32 * scale).round() as usize; height = (height as f32 * scale).round() as usize;
        let time = mpv.time();
        let fps = mpv.fps();
        let frame_number = (time * fps.max(1.0)).max(0.0) as usize;
        let Some(mut pixels) = mpv.render(width, height) else { return };
        match (self.bypass, self.effect_mode) {
            (false, EffectMode::Ntsc) => {
                self.engine.process(&mut pixels, width, height, frame_number);
                bgr0_to_rgba(&mut pixels);
            }
            (false, EffectMode::Shaders) => {
                bgr0_to_rgba(&mut pixels);
                if let Some(shader) = &mut self.shader {
                    if !shader.process_rgba(&mut pixels, width, height, frame_number, fps) {
                        self.error = shader.last_error().to_string();
                    }
                }
            }
            _ => bgr0_to_rgba(&mut pixels),
        }
        let image = egui::ColorImage::from_rgba_unmultiplied([width, height], &pixels);
        if let Some(texture) = &mut self.texture { texture.set(image, egui::TextureOptions::LINEAR); }
        else { self.texture = Some(ctx.load_texture("video", image, egui::TextureOptions::LINEAR)); }
    }

    fn connect_jellyfin(&mut self) {
        match Jellyfin::login(&self.server, &self.username, &self.password) {
            Ok(client) => { self.jellyfin = Some(client); self.password.clear(); self.error.clear(); self.load_libraries(); }
            Err(e) => self.error = e,
        }
    }
    fn load_libraries(&mut self) {
        if let Some(client) = &self.jellyfin { match client.libraries() { Ok(v) => self.libraries = v, Err(e) => self.error = e } }
    }
    fn load_children(&mut self) {
        let Some(parent) = self.navigation.last().map(|i| i.Id.clone()).or(self.library_id.clone()) else { return };
        if let Some(client) = &self.jellyfin {
            match client.children(&parent, &self.search, &self.sort, self.descending) { Ok(v) => self.items = organize(v, self.navigation.last().and_then(|i| i.Type.as_deref())), Err(e) => self.error = e }
        }
    }
    fn restore_navigation(&mut self, path: Vec<(String, String, String)>) {
        if let Some((id, _, _)) = path.first() { self.library_id = Some(id.clone()); }
        self.navigation = path.into_iter().skip(1).map(|(Id, Name, kind)| Item { Id, Name, Type: Some(kind), ..Default::default() }).collect();
        self.load_children();
    }
    fn play_jellyfin_item(&mut self, item: Item) {
        let Some(client) = &self.jellyfin else { return };
        if item.Type.as_deref() == Some("Episode") {
            match client.series_queue(&item) {
                Ok(queue) => { let entry = queue.entries[queue.index].clone(); self.open_source(entry.url.to_string(), entry.title, Some(queue), None, true); self.show_jellyfin = false; }
                Err(e) => self.error = e,
            }
        } else {
            self.open_source(client.stream_url(&item.Id).to_string(), item.Name, None, None, true); self.show_jellyfin = false;
        }
    }

    fn stock_shader_path(&self, index: usize) -> Option<PathBuf> {
        let (_, relative) = shader::STOCK_PRESETS.get(index)?;
        let path = self.shader_root.as_ref()?.join(relative);
        path.is_file().then_some(path)
    }

    fn ensure_shader(&mut self) -> bool {
        if self.shader.is_some() { return true; }
        match ShaderEngine::new() {
            Ok(shader) => { self.shader = Some(shader); true }
            Err(error) => { self.error = error; false }
        }
    }

    fn load_shader(&mut self, path: PathBuf) {
        if !self.ensure_shader() { return; }
        match self.shader.as_mut().expect("shader initialized").load(&path) {
            Ok(()) => { self.shader_preset = Some(path); self.error.clear(); }
            Err(error) => self.error = error,
        }
    }

    fn effects_ui(&mut self, ui: &mut egui::Ui) {
        ui.heading("Video effect");
        let previous_mode = self.effect_mode;
        ui.horizontal(|ui| {
            ui.selectable_value(&mut self.effect_mode, EffectMode::Ntsc, "NTSC engine");
            ui.selectable_value(&mut self.effect_mode, EffectMode::Shaders, "Shaders engine");
        });
        if previous_mode != self.effect_mode && self.effect_mode == EffectMode::Shaders && self.shader_preset.is_none() {
            if let Some(path) = self.stock_shader_path(0) { self.load_shader(path); }
        }
        ui.checkbox(&mut self.bypass, "Bypass effect");
        ui.separator();

        match self.effect_mode {
            EffectMode::Ntsc => self.ntsc_effects_ui(ui),
            EffectMode::Shaders => self.shader_effects_ui(ui),
        }
    }

    fn ntsc_effects_ui(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            if ui.button("Reset").clicked() { self.engine.reset(); }
            if ui.button("Load preset…").clicked() && let Some(path) = rfd::FileDialog::new().add_filter("JSON", &["json"]).pick_file() {
                match std::fs::read_to_string(path) { Ok(text) if self.engine.load_json(&text) => {}, _ => self.error = "That is not a compatible ntsc-rs preset".into() }
            }
            if ui.button("Save preset…").clicked() && let Some(path) = rfd::FileDialog::new().add_filter("JSON", &["json"]).set_file_name("My Preset.json").save_file() {
                if let Some(json) = self.engine.json() { if let Err(e) = std::fs::write(path, json) { self.error = e.to_string(); } }
            }
        });
        if !self.ntsc_stock_presets.is_empty() {
            ui.label("Stock ntsc-rs presets");
            let presets = self.ntsc_stock_presets.clone();
            for preset in presets {
                if ui.button(&preset.name).on_hover_text(&preset.credit).clicked() {
                    if !self.engine.load_json(&preset.json) { self.error = format!("Could not load {}", preset.name); }
                }
            }
        }
        ui.separator();
        egui::ScrollArea::vertical().show(ui, |ui| {
            for info in self.setting_infos.clone() {
                ui.add_space((info.depth * 2) as f32);
                let mut value = self.engine.value(info.index);
                let changed = match &info.kind {
                    ControlKind::Bool | ControlKind::Group => { let mut checked = value >= 0.5; let r = ui.checkbox(&mut checked, &info.label).on_hover_text(&info.description); value = checked as u8 as f64; r.changed() }
                    ControlKind::Float(min, max) => ui.add(egui::Slider::new(&mut value, *min..=*max).text(&info.label)).on_hover_text(&info.description).changed(),
                    ControlKind::Int(min, max) => ui.add(egui::Slider::new(&mut value, *min as f64..=*max as f64).integer().text(&info.label)).on_hover_text(&info.description).changed(),
                    ControlKind::Enum(options) => {
                        let before = value;
                        egui::ComboBox::from_label(&info.label).selected_text(options.iter().find(|(_, v)| *v as f64 == value).map(|v| v.0.as_str()).unwrap_or("—")).show_ui(ui, |ui| {
                            for (label, option) in options { ui.selectable_value(&mut value, *option as f64, label); }
                        }); before != value
                    }
                };
                if changed { self.engine.set_value(info.index, value); }
            }
        });
    }

    fn shader_effects_ui(&mut self, ui: &mut egui::Ui) {
        if self.shader_root.is_none() {
            ui.colored_label(egui::Color32::RED, "The slang-shaders folder is missing beside NTSC Player.exe");
            return;
        }
        ui.horizontal_wrapped(|ui| {
            if ui.button("Reset parameters").clicked() && let Some(shader) = &mut self.shader { shader.reset(); }
            if ui.button("Load external…").clicked() && let Some(path) = rfd::FileDialog::new().add_filter("RetroArch preset", &["slangp"]).pick_file() { self.load_shader(path); }
            if ui.button("Save preset…").clicked()
                && let Some(text) = self.shader.as_ref().and_then(ShaderEngine::user_preset_text)
                && let Some(path) = rfd::FileDialog::new().add_filter("RetroArch preset", &["slangp"]).set_file_name("My Shader.slangp").save_file()
                && let Err(error) = std::fs::write(path, text) { self.error = error.to_string(); }
        });
        ui.label("Stock presets");
        ui.horizontal_wrapped(|ui| {
            for (index, (name, _)) in shader::STOCK_PRESETS.iter().enumerate() {
                if ui.small_button(*name).clicked() && let Some(path) = self.stock_shader_path(index) { self.load_shader(path); }
            }
        });
        ui.separator();
        ui.label(format!("Shader library ({} presets)", self.shader_presets.len()));
        ui.add(egui::TextEdit::singleline(&mut self.shader_filter).hint_text("Filter shaders…"));
        let needle = self.shader_filter.to_lowercase();
        let root = self.shader_root.clone().expect("checked above");
        let matching: Vec<usize> = self.shader_presets.iter().enumerate()
            .filter(|(_, path)| needle.is_empty() || shader::display_path(&root, path).to_lowercase().contains(&needle))
            .map(|(index, _)| index).collect();
        let mut load = None;
        egui::ScrollArea::vertical().id_salt("shader-library").max_height(260.0).show_rows(ui, 20.0, matching.len(), |ui, rows| {
            for row in rows {
                let path = &self.shader_presets[matching[row]];
                let selected = self.shader_preset.as_ref() == Some(path);
                if ui.selectable_label(selected, shader::display_path(&root, path)).clicked() { load = Some(path.clone()); }
            }
        });
        if let Some(path) = load { self.load_shader(path); }
        ui.separator();
        let loaded_name = self.shader.as_ref().and_then(ShaderEngine::loaded_preset)
            .map(|path| shader::display_path(&root, path)).unwrap_or_else(|| "No shader loaded".into());
        ui.label(loaded_name);
        let parameters: Vec<ShaderParameter> = self.shader.as_ref().map(|shader| shader.parameters().to_vec()).unwrap_or_default();
        egui::ScrollArea::vertical().id_salt("shader-parameters").show(ui, |ui| {
            for (index, parameter) in parameters.iter().enumerate() {
                let Some(shader) = &mut self.shader else { break };
                let mut value = shader.value(index);
                let step = parameter.step.max(0.000_001) as f64;
                if ui.add(egui::Slider::new(&mut value, parameter.minimum..=parameter.maximum).step_by(step).text(&parameter.description))
                    .on_hover_text(&parameter.name).changed() { shader.set_value(index, value); }
            }
        });
    }

    fn jellyfin_ui(&mut self, ctx: &egui::Context) {
        let mut open = self.show_jellyfin;
        egui::Window::new("Jellyfin Library").open(&mut open).default_size([900.0, 620.0]).show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label("Server"); ui.text_edit_singleline(&mut self.server);
                ui.label("User"); ui.text_edit_singleline(&mut self.username);
                ui.add(egui::TextEdit::singleline(&mut self.password).password(true).hint_text("Password"));
                if ui.button("Connect").clicked() { self.connect_jellyfin(); }
            });
            ui.horizontal(|ui| {
                if ui.button("Back").clicked() && !self.navigation.is_empty() { self.navigation.pop(); self.load_children(); }
                egui::ComboBox::from_id_salt("library").selected_text(self.libraries.iter().find(|i| Some(&i.Id) == self.library_id.as_ref()).map(|i| i.Name.as_str()).unwrap_or("Library")).show_ui(ui, |ui| {
                    let libs = self.libraries.clone(); for library in libs { if ui.selectable_label(Some(&library.Id) == self.library_id.as_ref(), &library.Name).clicked() { self.library_id = Some(library.Id); self.navigation.clear(); self.load_children(); } }
                });
                ui.text_edit_singleline(&mut self.search);
                if ui.button("Search").clicked() { self.load_children(); }
                egui::ComboBox::from_id_salt("sort").selected_text(&self.sort).show_ui(ui, |ui| {
                    for (label, value) in [("Name", "SortName"), ("Date added", "DateCreated"), ("Release date", "PremiereDate"), ("Year", "ProductionYear"), ("Rating", "CommunityRating")] { ui.selectable_value(&mut self.sort, value.into(), label); }
                });
                if ui.checkbox(&mut self.descending, "Descending").changed() { self.load_children(); }
            });
            ui.label(self.navigation.iter().map(|i| i.Name.as_str()).collect::<Vec<_>>().join("  ›  "));
            ui.separator();
            let mut action = None;
            egui::ScrollArea::vertical().id_salt("jellyfin-items").show(ui, |ui| {
                for item in &self.items {
                    let title = if item.Type.as_deref() == Some("Episode") { format!("S{:02}E{:02}  {}", item.ParentIndexNumber.unwrap_or(0), item.IndexNumber.unwrap_or(0), item.Name) } else { item.Name.clone() };
                    let response = ui.selectable_label(self.selected_item.as_ref() == Some(&item.Id), format!("{title}    {}", item.Type.as_deref().unwrap_or("")));
                    if response.clicked() { self.selected_item = Some(item.Id.clone()); }
                    if response.double_clicked() { action = Some(item.clone()); }
                }
            });
            if let Some(item) = action {
                if matches!(item.Type.as_deref(), Some("Movie" | "Episode" | "Video" | "MusicVideo")) { self.play_jellyfin_item(item); }
                else { self.navigation.push(item); self.search.clear(); self.load_children(); }
            }
        });
        self.show_jellyfin = open;
    }

    fn controls(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            if ui.button("Open").clicked() && let Some(path) = rfd::FileDialog::new().pick_file() { self.open_file(path); }
            if ui.button("Jellyfin").clicked() { self.show_jellyfin = true; }
            if let Some(q) = &self.queue {
                if ui.add_enabled(q.index > 0, egui::Button::new("Previous Episode")).clicked() { self.previous_episode(); }
            }
            if ui.button("−10").clicked() { if let Some(mpv) = &mut self.mpv { mpv.seek(-10.0, true); } }
            if ui.button(if self.playing { "Pause" } else { "Play" }).clicked() { self.toggle_play(); }
            if ui.button("+10").clicked() { if let Some(mpv) = &mut self.mpv { mpv.seek(10.0, true); } }
            if let Some(q) = &self.queue {
                if ui.add_enabled(q.index + 1 < q.entries.len(), egui::Button::new("Next Episode")).clicked() { self.next_episode(); }
            }
            ui.label(&self.title);
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui.button("Effects (P)").clicked() { self.show_effects = !self.show_effects; }
                if ui.selectable_label(self.crt_fill, "CRT Fill (C)").on_hover_text("Crop wider video to 4:3; native 4:3 is unchanged").clicked() { self.crt_fill = !self.crt_fill; }
                if ui.button("Fullscreen").clicked() { self.fullscreen = !self.fullscreen; ui.ctx().send_viewport_cmd(egui::ViewportCommand::Fullscreen(self.fullscreen)); }
                if ui.add(egui::Slider::new(&mut self.volume, 0.0..=1.0).show_value(false).text("Volume")).changed() { if let Some(mpv) = &mut self.mpv { mpv.set_volume(self.volume); } }
            });
        });
        if let Some(mpv) = &mut self.mpv {
            let mut time = mpv.time(); let duration = mpv.duration().max(1.0);
            ui.horizontal(|ui| { ui.label(format_time(time)); if ui.add(egui::Slider::new(&mut time, 0.0..=duration).show_value(false)).changed() { mpv.seek(time, false); self.ready_for_eof = false; } ui.label(format_time(duration)); });
        }
    }
}

impl eframe::App for WindowsPlayer {
    fn update(&mut self, ctx: &egui::Context, frame: &mut eframe::Frame) {
        for dropped in ctx.input(|i| i.raw.dropped_files.clone()) { if let Some(path) = dropped.path { self.open_file(path); break; } }
        if ctx.input(|i| i.key_pressed(egui::Key::Space) && !i.modifiers.any()) { self.toggle_play(); }
        if ctx.input(|i| i.key_pressed(egui::Key::ArrowLeft)) { if let Some(mpv) = &mut self.mpv { mpv.seek(-10.0, true); } }
        if ctx.input(|i| i.key_pressed(egui::Key::ArrowRight)) { if let Some(mpv) = &mut self.mpv { mpv.seek(10.0, true); } }
        if ctx.input(|i| i.key_pressed(egui::Key::P) && !i.modifiers.any()) { self.show_effects = !self.show_effects; }
        if !ctx.wants_keyboard_input() && ctx.input(|i| i.key_pressed(egui::Key::C) && !i.modifiers.any()) { self.crt_fill = !self.crt_fill; }
        if ctx.input(|i| i.key_pressed(egui::Key::F11)) { self.fullscreen = !self.fullscreen; ctx.send_viewport_cmd(egui::ViewportCommand::Fullscreen(self.fullscreen)); }
        let pointer = ctx.input(|i| i.pointer.latest_pos());
        if pointer != self.last_mouse { self.last_mouse = pointer; self.last_mouse_activity = Instant::now(); self.controls_visible = true; }
        if self.fullscreen && self.last_mouse_activity.elapsed() > Duration::from_secs(2) { self.controls_visible = false; }
        self.update_video(ctx);
        egui::CentralPanel::default().frame(egui::Frame::NONE.fill(egui::Color32::BLACK)).show(ctx, |ui| {
            let available = ui.available_size();
            if let Some(texture) = &self.texture {
                let source = texture.size_vec2();
                let uv = if self.crt_fill { crop_uv(source.x / source.y, 4.0 / 3.0) } else { egui::Rect::from_min_max(egui::Pos2::ZERO, egui::pos2(1.0, 1.0)) };
                let visible_aspect = if self.crt_fill { 4.0 / 3.0 } else { source.x / source.y };
                let target = fit_size(available, visible_aspect);
                ui.centered_and_justified(|ui| { ui.add(egui::Image::new(texture).uv(uv).fit_to_exact_size(target)); });
            } else { ui.centered_and_justified(|ui| { ui.label("Drop a video here"); }); }
        });
        if !self.fullscreen || self.controls_visible { egui::TopBottomPanel::bottom("controls").show(ctx, |ui| self.controls(ui)); }
        if self.show_effects { egui::SidePanel::right("effects").resizable(false).default_width(320.0).show(ctx, |ui| self.effects_ui(ui)); }
        if self.show_jellyfin { self.jellyfin_ui(ctx); }
        if !self.error.is_empty() { egui::TopBottomPanel::top("error").show(ctx, |ui| { ui.colored_label(egui::Color32::RED, &self.error); }); }
        if self.last_save.elapsed() >= Duration::from_secs(2) {
            if let Some(storage) = frame.storage_mut() { self.save(storage); storage.flush(); }
            self.last_save = Instant::now();
        }
        ctx.request_repaint_after(Duration::from_millis(16));
    }
    fn save(&mut self, storage: &mut dyn eframe::Storage) {
        let client = self.jellyfin.as_ref();
        let navigation = self.library_id.iter().map(|id| (id.clone(), "Library".into(), "CollectionFolder".into()))
            .chain(self.navigation.iter().map(|i| (i.Id.clone(), i.Name.clone(), i.Type.clone().unwrap_or_else(|| "Folder".into())))).collect();
        let state = SavedState {
            server: self.server.clone(), username: self.username.clone(), token: client.map(|c| c.token.clone()).unwrap_or_default(), user_id: client.map(|c| c.user_id.clone()).unwrap_or_default(),
            library_id: self.library_id.clone(), navigation, last_url: self.current_url.clone(), last_title: self.title.clone(),
            last_position: self.mpv.as_ref().map(Mpv::time).unwrap_or(0.0), queue: self.queue.clone(), volume: self.volume,
            crt_fill: self.crt_fill, effect_mode: self.effect_mode,
            shader_preset: self.shader_preset.as_ref().map(|path| path.to_string_lossy().to_string()),
        };
        eframe::set_value(storage, STATE_KEY, &state);
    }
}

impl Drop for WindowsPlayer { fn drop(&mut self) { sleep::set_playing(false); } }

fn organize(items: Vec<Item>, parent: Option<&str>) -> Vec<Item> {
    if parent == Some("Season") { return items; }
    let episodes: Vec<_> = items.iter().filter(|i| i.Type.as_deref() == Some("Episode")).cloned().collect();
    if episodes.is_empty() { return items; }
    let mut folders = std::collections::BTreeMap::new();
    for episode in episodes {
        let (id, name, kind) = if parent == Some("Series") { (episode.SeasonId.clone(), format!("Season {}", episode.ParentIndexNumber.unwrap_or(0)), "Season") } else { (episode.SeriesId.clone(), episode.Name.clone(), "Series") };
        if let Some(id) = id { folders.entry(id.clone()).or_insert(Item { Id: id, Name: name, Type: Some(kind.into()), ..Default::default() }); }
    }
    let mut result: Vec<_> = items.into_iter().filter(|i| i.Type.as_deref() != Some("Episode")).collect(); result.extend(folders.into_values()); result
}
fn format_time(seconds: f64) -> String { let n = seconds.max(0.0) as u64; if n >= 3600 { format!("{}:{:02}:{:02}", n / 3600, n / 60 % 60, n % 60) } else { format!("{}:{:02}", n / 60, n % 60) } }

fn bgr0_to_rgba(pixels: &mut [u8]) {
    for pixel in pixels.chunks_exact_mut(4) { pixel.swap(0, 2); pixel[3] = 255; }
}

fn crop_uv(source_aspect: f32, target_aspect: f32) -> egui::Rect {
    if source_aspect > target_aspect {
        let visible = target_aspect / source_aspect;
        let margin = (1.0 - visible) * 0.5;
        egui::Rect::from_min_max(egui::pos2(margin, 0.0), egui::pos2(1.0 - margin, 1.0))
    } else if source_aspect < target_aspect {
        let visible = source_aspect / target_aspect;
        let margin = (1.0 - visible) * 0.5;
        egui::Rect::from_min_max(egui::pos2(0.0, margin), egui::pos2(1.0, 1.0 - margin))
    } else {
        egui::Rect::from_min_max(egui::Pos2::ZERO, egui::pos2(1.0, 1.0))
    }
}

fn fit_size(available: egui::Vec2, aspect: f32) -> egui::Vec2 {
    if available.x / available.y > aspect { egui::vec2(available.y * aspect, available.y) }
    else { egui::vec2(available.x, available.x / aspect) }
}

fn main() -> eframe::Result {
    let options = eframe::NativeOptions { viewport: egui::ViewportBuilder::default().with_title("NTSC Player").with_inner_size([1120.0, 700.0]).with_drag_and_drop(true), ..Default::default() };
    eframe::run_native("NTSC Player", options, Box::new(|cc| Ok(Box::new(WindowsPlayer::new(cc)))))
}
