use libloading::Library;
use std::ffi::{c_char, c_int, c_void, CStr, CString};
use std::path::Path;

#[repr(C)]
struct RenderParam { kind: c_int, data: *mut c_void }

type Create = unsafe extern "C" fn() -> *mut c_void;
type Initialize = unsafe extern "C" fn(*mut c_void) -> c_int;
type Terminate = unsafe extern "C" fn(*mut c_void);
type SetOption = unsafe extern "C" fn(*mut c_void, *const c_char, *const c_char) -> c_int;
type Command = unsafe extern "C" fn(*mut c_void, *const *const c_char) -> c_int;
type GetProperty = unsafe extern "C" fn(*mut c_void, *const c_char, c_int, *mut c_void) -> c_int;
type SetProperty = unsafe extern "C" fn(*mut c_void, *const c_char, c_int, *mut c_void) -> c_int;
type SetPropertyString = unsafe extern "C" fn(*mut c_void, *const c_char, *const c_char) -> c_int;
type WaitEvent = unsafe extern "C" fn(*mut c_void, f64) -> *const MpvEvent;
type RenderCreate = unsafe extern "C" fn(*mut *mut c_void, *mut c_void, *mut RenderParam) -> c_int;
type Render = unsafe extern "C" fn(*mut c_void, *mut RenderParam) -> c_int;
type RenderFree = unsafe extern "C" fn(*mut c_void);
type MpvFree = unsafe extern "C" fn(*mut c_void);

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum TrackKind { Audio, Subtitle, Video }

#[derive(Clone, Debug)]
pub struct MediaTrack { pub id: i64, pub kind: TrackKind, pub title: String, pub language: String, pub codec: String, pub selected: bool }
impl MediaTrack {
    pub fn display_title(&self) -> String {
        let parts: Vec<_> = [self.language.to_uppercase(), self.title.clone(), self.codec.to_uppercase()].into_iter().filter(|v| !v.is_empty()).collect();
        if parts.is_empty() { format!("Track {}", self.id) } else { parts.join(" · ") }
    }
}

#[repr(C)]
struct MpvEvent { event_id: c_int, error: c_int, reply_userdata: u64, data: *mut c_void }

#[repr(C)]
struct MpvEventEndFile {
    reason: c_int,
    error: c_int,
    playlist_entry_id: i64,
    playlist_insert_id: i64,
    playlist_insert_num_entries: c_int,
}

const MPV_EVENT_NONE: c_int = 0;
const MPV_EVENT_END_FILE: c_int = 7;
pub const END_FILE_REASON_EOF: c_int = 0;
pub const END_FILE_REASON_STOP: c_int = 2;

pub struct Mpv {
    _lib: Library,
    handle: *mut c_void,
    render: *mut c_void,
    command: Command,
    get_property: GetProperty,
    set_property: SetProperty,
    set_property_string: SetPropertyString,
    wait_event: WaitEvent,
    render_frame: Render,
    render_free: RenderFree,
    mpv_free: MpvFree,
    terminate: Terminate,
    ntsc_cadence: bool,
    crt_fill: bool,
}

unsafe impl Send for Mpv {}

impl Mpv {
    pub fn new() -> Result<Self, String> {
        let lib = unsafe { Library::new("mpv-2.dll") }
            .or_else(|_| unsafe { Library::new("libmpv-2.dll") })
            .map_err(|_| "mpv-2.dll was not found beside NTSC Player.exe".to_string())?;
        unsafe {
            let create: Create = *lib.get(b"mpv_create\0").map_err(err)?;
            let initialize: Initialize = *lib.get(b"mpv_initialize\0").map_err(err)?;
            let set_option: SetOption = *lib.get(b"mpv_set_option_string\0").map_err(err)?;
            let command: Command = *lib.get(b"mpv_command\0").map_err(err)?;
            let get_property: GetProperty = *lib.get(b"mpv_get_property\0").map_err(err)?;
            let set_property: SetProperty = *lib.get(b"mpv_set_property\0").map_err(err)?;
            let set_property_string: SetPropertyString = *lib.get(b"mpv_set_property_string\0").map_err(err)?;
            let wait_event: WaitEvent = *lib.get(b"mpv_wait_event\0").map_err(err)?;
            let render_create: RenderCreate = *lib.get(b"mpv_render_context_create\0").map_err(err)?;
            let render_frame: Render = *lib.get(b"mpv_render_context_render\0").map_err(err)?;
            let render_free: RenderFree = *lib.get(b"mpv_render_context_free\0").map_err(err)?;
            let mpv_free: MpvFree = *lib.get(b"mpv_free\0").map_err(err)?;
            let terminate: Terminate = *lib.get(b"mpv_terminate_destroy\0").map_err(err)?;
            let handle = create();
            if handle.is_null() { return Err("mpv_create failed".into()); }
            for (name, value) in [
                ("vo", "libmpv"), ("terminal", "no"), ("hwdec", "auto-safe"),
                // keep-open suppresses END_FILE and only pauses at eof-reached. The
                // player needs END_FILE's reason to distinguish clean EOF from a
                // network/demuxer failure before auto-advancing the episode queue.
                ("keep-open", "no"), ("audio-display", "no"), ("cache", "yes"),
                ("demuxer-readahead-secs", "30"), ("demuxer-max-bytes", "256MiB"),
                ("vf", "fps=30000/1001"),
            ] { set_option(handle, cs(name).as_ptr(), cs(value).as_ptr()); }
            if initialize(handle) < 0 { terminate(handle); return Err("mpv_initialize failed".into()); }
            let mut render = std::ptr::null_mut();
            let api = b"sw\0".as_ptr() as *mut c_void;
            let mut params = [RenderParam { kind: 1, data: api }, RenderParam { kind: 0, data: std::ptr::null_mut() }];
            if render_create(&mut render, handle, params.as_mut_ptr()) < 0 {
                terminate(handle); return Err("mpv software renderer initialization failed".into());
            }
            Ok(Self { _lib: lib, handle, render, command, get_property, set_property, set_property_string, wait_event,
                render_frame, render_free, mpv_free, terminate, ntsc_cadence: true, crt_fill: false })
        }
    }

    pub fn load(&mut self, source: &str) -> Result<(), String> {
        self.drain_events();
        let args = [cs("loadfile"), cs(source), cs("replace")];
        let ptrs = [args[0].as_ptr(), args[1].as_ptr(), args[2].as_ptr(), std::ptr::null()];
        if unsafe { (self.command)(self.handle, ptrs.as_ptr()) } < 0 { Err("mpv could not open this video".into()) } else { Ok(()) }
    }
    pub fn load_path(&mut self, path: &Path) -> Result<(), String> { self.load(&path.to_string_lossy()) }
    pub fn paused(&self) -> bool { self.flag("pause") }
    pub fn set_paused(&mut self, value: bool) { let mut v = value as c_int; unsafe { (self.set_property)(self.handle, cs("pause").as_ptr(), 3, (&mut v as *mut c_int).cast()); } }
    pub fn eof(&self) -> bool { self.flag("eof-reached") }
    pub fn take_end_file_reason(&mut self) -> Option<c_int> {
        let mut reason = None;
        loop {
            let event = unsafe { (self.wait_event)(self.handle, 0.0) };
            if event.is_null() || unsafe { (*event).event_id } == MPV_EVENT_NONE { break; }
            if unsafe { (*event).event_id } == MPV_EVENT_END_FILE && !unsafe { (*event).data }.is_null() {
                let end = unsafe { &*((*event).data.cast::<MpvEventEndFile>()) };
                reason = Some(end.reason);
            }
        }
        reason
    }
    pub fn time(&self) -> f64 { self.number("time-pos") }
    pub fn duration(&self) -> f64 { self.number("duration") }
    pub fn fps(&self) -> f64 { let n = self.number("estimated-vf-fps"); if n > 0.0 { n } else { 30000.0 / 1001.0 } }
    pub fn seek(&mut self, value: f64, relative: bool) {
        let args = [cs("seek"), cs(&format!("{value:.6}")), cs(if relative { "relative+exact" } else { "absolute+exact" })];
        let ptrs = [args[0].as_ptr(), args[1].as_ptr(), args[2].as_ptr(), std::ptr::null()];
        unsafe { (self.command)(self.handle, ptrs.as_ptr()); }
    }
    pub fn set_volume(&mut self, value: f64) { let mut v = value * 100.0; unsafe { (self.set_property)(self.handle, cs("volume").as_ptr(), 5, (&mut v as *mut f64).cast()); } }
    pub fn tracks(&self) -> Vec<MediaTrack> {
        (0..self.integer("track-list/count").max(0) as usize).filter_map(|index| {
            let kind = match self.string(&format!("track-list/{index}/type")).as_str() {
                "audio" => TrackKind::Audio, "sub" => TrackKind::Subtitle, "video" => TrackKind::Video, _ => return None,
            };
            Some(MediaTrack { id: self.integer(&format!("track-list/{index}/id")), kind,
                title: self.string(&format!("track-list/{index}/title")), language: self.string(&format!("track-list/{index}/lang")),
                codec: self.string(&format!("track-list/{index}/codec")), selected: self.flag(&format!("track-list/{index}/selected")) })
        }).collect()
    }
    pub fn select_audio(&mut self, id: i64) { let mut value = id; unsafe { (self.set_property)(self.handle, cs("aid").as_ptr(), 4, (&mut value as *mut i64).cast()); } }
    pub fn select_subtitle(&mut self, id: Option<i64>) {
        if let Some(mut value) = id { unsafe { (self.set_property)(self.handle, cs("sid").as_ptr(), 4, (&mut value as *mut i64).cast()); } }
        else { unsafe { (self.set_property_string)(self.handle, cs("sid").as_ptr(), cs("no").as_ptr()); } }
    }
    pub fn set_ntsc_cadence(&mut self, enabled: bool) {
        self.ntsc_cadence = enabled;
        self.update_filters();
    }
    pub fn set_crt_fill(&mut self, enabled: bool) { self.crt_fill = enabled; self.update_filters(); }
    pub fn size(&self) -> Option<(usize, usize)> {
        let w = self.integer("dwidth"); let h = self.integer("dheight");
        (w > 0 && h > 0).then_some((w as usize, h as usize))
    }
    pub fn render(&mut self, width: usize, height: usize) -> Option<Vec<u8>> {
        let mut pixels = vec![0; width.checked_mul(height)?.checked_mul(4)?];
        let mut size = [width as c_int, height as c_int];
        let mut stride = (width * 4) as usize;
        let format = b"bgr0\0".as_ptr() as *mut c_void;
        let pointer = pixels.as_mut_ptr() as *mut c_void;
        let mut params = [
            RenderParam { kind: 17, data: size.as_mut_ptr().cast() },
            RenderParam { kind: 18, data: format },
            RenderParam { kind: 19, data: (&mut stride as *mut usize).cast() },
            RenderParam { kind: 20, data: pointer },
            RenderParam { kind: 0, data: std::ptr::null_mut() },
        ];
        (unsafe { (self.render_frame)(self.render, params.as_mut_ptr()) } >= 0).then_some(pixels)
    }
    fn flag(&self, name: &str) -> bool { let mut v = 0i32; unsafe { (self.get_property)(self.handle, cs(name).as_ptr(), 3, (&mut v as *mut i32).cast()); } v != 0 }
    fn number(&self, name: &str) -> f64 { let mut v = 0.0; unsafe { (self.get_property)(self.handle, cs(name).as_ptr(), 5, (&mut v as *mut f64).cast()); } v }
    fn integer(&self, name: &str) -> i64 { let mut v = 0i64; unsafe { (self.get_property)(self.handle, cs(name).as_ptr(), 4, (&mut v as *mut i64).cast()); } v }
    fn string(&self, name: &str) -> String {
        let mut pointer: *mut c_char = std::ptr::null_mut();
        let result = unsafe { (self.get_property)(self.handle, cs(name).as_ptr(), 1, (&mut pointer as *mut *mut c_char).cast()) };
        if result < 0 || pointer.is_null() { return String::new(); }
        let value = unsafe { CStr::from_ptr(pointer) }.to_string_lossy().into_owned();
        unsafe { (self.mpv_free)(pointer.cast()); }
        value
    }
    fn update_filters(&mut self) {
        let value = match (self.ntsc_cadence, self.crt_fill) {
            (true, true) => "fps=30000/1001,crop=ih/3*4:ih",
            (true, false) => "fps=30000/1001",
            (false, true) => "crop=ih/3*4:ih",
            (false, false) => "",
        };
        let name = cs("vf"); let value = cs(value);
        unsafe { (self.set_property_string)(self.handle, name.as_ptr(), value.as_ptr()); }
    }
    fn drain_events(&mut self) {
        loop {
            let event = unsafe { (self.wait_event)(self.handle, 0.0) };
            if event.is_null() || unsafe { (*event).event_id } == MPV_EVENT_NONE { break; }
        }
    }
}

impl Drop for Mpv { fn drop(&mut self) { unsafe { (self.render_free)(self.render); (self.terminate)(self.handle); } } }
fn cs(value: &str) -> CString { CString::new(value).unwrap_or_default() }
fn err(e: libloading::Error) -> String { e.to_string() }
