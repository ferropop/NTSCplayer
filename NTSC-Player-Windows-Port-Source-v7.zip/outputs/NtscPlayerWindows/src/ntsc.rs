use ntsc_rs::{Context, NtscEffect};
use ntsc_rs::settings::{AnySetting, SettingDescriptor, SettingKind, SettingsList};
use ntsc_rs::settings::standard::*;
use ntsc_rs::yiq_fielding::Bgrx;

#[derive(Clone)]
pub enum ControlKind { Enum(Vec<(String, u32)>), Float(f64, f64), Int(i32, i32), Bool, Group }
#[derive(Clone)]
pub struct SettingInfo { pub index: usize, pub depth: usize, pub label: String, pub description: String, pub kind: ControlKind }

pub struct Engine { context: Context, effect: NtscEffect }

impl Engine {
    pub fn new() -> Self { Self { context: Context::new(), effect: standalone_saved_preset() } }
    pub fn reset(&mut self) { self.effect = standalone_saved_preset(); }
    pub fn process(&self, pixels: &mut [u8], width: usize, height: usize, frame: usize) {
        if pixels.len() >= width.saturating_mul(height).saturating_mul(4) {
            self.effect.apply_effect_to_buffer::<Bgrx, u8>(&self.context, (width, height), pixels, frame, [1.0, 1.0]);
        }
    }
    pub fn json(&self) -> Option<String> { SettingsList::<NtscEffect>::new().to_json_string(&self.effect).ok() }
    pub fn load_json(&mut self, text: &str) -> bool {
        if let Ok(effect) = SettingsList::<NtscEffect>::new().from_json(text) { self.effect = effect; true } else { false }
    }
    pub fn settings() -> Vec<SettingInfo> {
        let list = SettingsList::<NtscEffect>::new();
        let mut output = Vec::new();
        fn walk(items: &[SettingDescriptor<NtscEffect>], depth: usize, output: &mut Vec<SettingInfo>) {
            for descriptor in items {
                let index = output.len();
                let kind = match &descriptor.kind {
                    SettingKind::Enumeration { options } => ControlKind::Enum(options.iter().map(|o| (o.label.to_string(), o.index)).collect()),
                    SettingKind::Percentage { .. } => ControlKind::Float(0.0, 1.0),
                    SettingKind::IntRange { range } => ControlKind::Int(*range.start(), *range.end()),
                    SettingKind::FloatRange { range, .. } => ControlKind::Float(*range.start() as f64, *range.end() as f64),
                    SettingKind::Boolean => ControlKind::Bool,
                    SettingKind::Group { .. } => ControlKind::Group,
                };
                output.push(SettingInfo { index, depth, label: descriptor.label.to_string(), description: descriptor.description.unwrap_or("").to_string(), kind });
                if let SettingKind::Group { children } = &descriptor.kind { walk(children, depth + 1, output); }
            }
        }
        walk(&list.setting_descriptors, 0, &mut output);
        output
    }
    pub fn value(&self, index: usize) -> f64 {
        with_descriptor(index, |d| match (d.id.get)(&self.effect) { AnySetting::Enum(v) => v as f64, AnySetting::Int(v) => v as f64, AnySetting::Float(v) => v as f64, AnySetting::Bool(v) => v as u8 as f64 }).unwrap_or(0.0)
    }
    pub fn set_value(&mut self, index: usize, value: f64) {
        let _ = with_descriptor(index, |d| {
            let setting = match &d.kind {
                SettingKind::Enumeration { .. } => AnySetting::Enum(value.max(0.0).round() as u32),
                SettingKind::IntRange { .. } => AnySetting::Int(value.round() as i32),
                SettingKind::Percentage { .. } | SettingKind::FloatRange { .. } => AnySetting::Float(value as f32),
                SettingKind::Boolean | SettingKind::Group { .. } => AnySetting::Bool(value >= 0.5),
            };
            (d.id.set)(&mut self.effect, setting)
        });
    }
}

fn with_descriptor<R>(index: usize, callback: impl FnOnce(&SettingDescriptor<NtscEffect>) -> R) -> Option<R> {
    fn find<'a>(items: &'a [SettingDescriptor<NtscEffect>], remaining: &mut usize) -> Option<&'a SettingDescriptor<NtscEffect>> {
        for item in items {
            if *remaining == 0 { return Some(item); }
            *remaining -= 1;
            if let SettingKind::Group { children } = &item.kind && let Some(found) = find(children, remaining) { return Some(found); }
        }
        None
    }
    let list = SettingsList::<NtscEffect>::new();
    let mut remaining = index;
    find(&list.setting_descriptors, &mut remaining).map(callback)
}

fn standalone_saved_preset() -> NtscEffect {
    let mut effect = NtscEffect::default();
    effect.random_seed = 2_079_714_514;
    effect.use_field = UseField::Upper;
    effect.filter_type = FilterType::Butterworth;
    effect.input_luma_filter = LumaLowpass::Notch;
    effect.chroma_lowpass_in = ChromaLowpass::Full;
    effect.composite_sharpening = 2.0;
    effect.composite_noise.enabled = true;
    effect.composite_noise.settings.intensity = 0.25;
    effect.composite_noise.settings.frequency = 1.0;
    effect.composite_noise.settings.detail = 5;
    effect.snow_intensity = 0.00009;
    effect.snow_anisotropy = 0.95;
    effect.video_scanline_phase_shift = PhaseShift::Degrees180;
    effect.video_scanline_phase_shift_offset = 3;
    effect.chroma_demodulation = ChromaDemodulationFilter::Box;
    effect.luma_smear = 0.975;
    effect.head_switching.enabled = true;
    effect.head_switching.settings.height = 14;
    effect.head_switching.settings.offset = 17;
    effect.head_switching.settings.horiz_shift = 72.0;
    effect.head_switching.settings.mid_line.enabled = true;
    effect.tracking_noise.enabled = true;
    effect.tracking_noise.settings.height = 21;
    effect.tracking_noise.settings.wave_intensity = 34.0;
    effect.tracking_noise.settings.snow_intensity = 0.0;
    effect.tracking_noise.settings.snow_anisotropy = 0.425;
    effect.tracking_noise.settings.noise_intensity = 1.0;
    effect.ringing.enabled = true;
    effect.ringing.settings.frequency = 0.04;
    effect.ringing.settings.power = 1.95;
    effect.ringing.settings.intensity = 0.8;
    effect.luma_noise.enabled = true;
    effect.luma_noise.settings.intensity = 0.17;
    effect.luma_noise.settings.frequency = 0.685;
    effect.luma_noise.settings.detail = 5;
    effect.chroma_noise.enabled = true;
    effect.chroma_noise.settings.intensity = 1.0;
    effect.chroma_noise.settings.frequency = 0.145;
    effect.chroma_noise.settings.detail = 5;
    effect.chroma_phase_noise_intensity = 0.0001;
    effect.chroma_delay_horizontal = 8.5;
    effect.chroma_delay_vertical = -1;
    effect.vhs_settings.enabled = true;
    effect.vhs_settings.settings.tape_speed = VHSTapeSpeed::EP;
    effect.vhs_settings.settings.chroma_loss = 0.00015;
    effect.vhs_settings.settings.sharpen.enabled = true;
    effect.vhs_settings.settings.sharpen.settings.intensity = 0.3;
    effect.chroma_vert_blend = true;
    effect.chroma_lowpass_out = ChromaLowpass::Full;
    effect.scale.enabled = true;
    effect
}
